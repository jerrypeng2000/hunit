import puppeteer from 'puppeteer-core';
import http from 'node:http';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const screenshotDir = resolve(root, 'screenshots');
mkdirSync(screenshotDir, { recursive: true });

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>测试页</title></head><body><h1>商品包装</h1><p id="target">包装箱尺寸：<span id="dim">12x6x1</span>，重量 <span id="w">500g</span>，价格 <span id="c">$20</span>。</p></body></html>`);
});

await new Promise((resolveListen) => server.listen(8766, '127.0.0.1', resolveListen));

let browser;
const errors = [];
try {
  browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: false,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--window-position=-32000,-32000',
      `--disable-extensions-except=${dist}`,
      `--load-extension=${dist}`
    ],
    defaultViewport: { width: 1280, height: 900 }
  });

  await new Promise((r) => setTimeout(r, 2500));
  const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  console.log('extension id:', extensionId);

  const popup = await browser.newPage();
  popup.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`popup console: ${msg.text()}`);
  });
  popup.on('pageerror', (err) => errors.push(`popup pageerror: ${err.message}`));
  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => document.querySelector('#quotaValue')?.textContent.trim() !== '—', { timeout: 10000 });
  const title = await popup.$eval('h1', (el) => el.textContent.trim());
  if (title !== '换算通 HUnit') throw new Error(`popup title unexpected: ${title}`);
  console.log('popup title OK, quota:', await popup.$eval('#quotaValue', (el) => el.textContent.trim()));

  // 尺寸换算
  await popup.select('#dimUnit', 'in');
  await popup.click('#modeSeg [data-mode="3d"]');
  await popup.type('#dimLength', '12');
  await popup.type('#dimWidth', '6');
  await popup.type('#dimHeight', '1');
  await new Promise((r) => setTimeout(r, 400));
  const lines = await popup.$$eval('#dimLines .result-line', (els) => els.map((el) => el.textContent.trim()));
  console.log('dim lines:', lines.join(' | '));
  const joined = lines.join(' | ');
  if (!joined.includes('30.48 cm')) throw new Error('expected 30.48 cm in length row');
  if (!joined.includes('72.00 in³')) throw new Error('expected volume row');
  if (!joined.includes('0.24 kg')) throw new Error('expected volumetric weight row');

  // 加入常用表
  await popup.click('#addDimCommonBtn');
  await new Promise((r) => setTimeout(r, 300));
  await popup.click('.tab-btn[data-tab="common"]');
  await popup.waitForSelector('#commonList .common-item');
  const commonCount = await popup.$$eval('#commonList .common-item', (els) => els.length);
  if (commonCount < 1) throw new Error('common item not added');
  console.log('common items:', commonCount);
  await popup.waitForSelector('#commonList .common-output-wrap');
  const outputText = await popup.$eval('#commonList .common-output', (el) => el.textContent.trim());
  if (!outputText) throw new Error('common output text missing');
  console.log('common output:', outputText);

  // 单行结果加入常用表
  await popup.click('.tab-btn[data-tab="dim"]');
  await popup.waitForSelector('#dimLines .result-line .save-row-btn');
  await popup.click('#dimLines .result-line:first-child .save-row-btn');
  await new Promise((r) => setTimeout(r, 300));
  await popup.click('.tab-btn[data-tab="common"]');
  await popup.waitForFunction(() => document.querySelectorAll('#commonList .common-item').length >= 2, { timeout: 5000 });
  console.log('common items after row save:', await popup.$$eval('#commonList .common-item', (els) => els.length));

  // 定价
  await popup.click('.tab-btn[data-tab="price"]');
  await popup.evaluate(() => {
    const set = (id, v) => {
      const el = document.getElementById(id);
      el.value = v;
      el.dispatchEvent(new Event('input'));
    };
    set('priceCost', '15');
    set('priceProfit', '30');
    set('priceCommission', '15');
    set('priceRate', '7.2');
  });
  await popup.waitForFunction(() => !document.querySelector('#priceResultCard')?.hidden, { timeout: 5000 });
  const priceText = await popup.$eval('#priceResult', (el) => el.textContent.trim());
  if (!priceText.includes('$') || priceText.includes('$0.00')) throw new Error(`pricing result wrong: ${priceText}`);
  console.log('pricing result:', priceText);

  // 只输入成本也应立即显示售价（默认已自动填好利润/佣金/汇率）
  await popup.evaluate(() => {
    const el = document.getElementById('priceCost');
    el.value = '20';
    el.dispatchEvent(new Event('input'));
  });
  await new Promise((r) => setTimeout(r, 300));
  const priceCostOnly = await popup.$eval('#priceResult', (el) => el.textContent.trim());
  if (!priceCostOnly.includes('$') || priceCostOnly.includes('$0.00')) throw new Error(`cost-only pricing wrong: ${priceCostOnly}`);
  console.log('pricing result (cost only):', priceCostOnly);

  // 海关编码
  await popup.click('.tab-btn[data-tab="hs"]');
  await popup.type('#hsSearch', '手机壳');
  await popup.click('#hsSearchBtn');
  await popup.waitForSelector('#hsResults .hs-item', { timeout: 20000 });
  const hsCount = await popup.$$eval('#hsResults .hs-item', (els) => els.length);
  if (hsCount < 1) throw new Error('hs search returned no results');
  console.log('hs results:', hsCount);
  await popup.click('#hsResults .hs-item');
  await popup.waitForFunction(() => !document.querySelector('#hsDetailCard')?.hidden, { timeout: 20000 });
  const hsDetail = await popup.$eval('#hsDetailCard', (el) => el.textContent);
  if (!hsDetail.includes('最惠国税率') && !hsDetail.includes('增值税')) throw new Error('hs detail missing tax fields');
  await popup.screenshot({ path: resolve(screenshotDir, 'popup.png') });

  // 设置页签
  await popup.click('.tab-btn[data-tab="settings"]');
  await popup.waitForSelector('#baseUrl');
  await new Promise((r) => setTimeout(r, 300));
  await popup.screenshot({ path: resolve(screenshotDir, 'settings.png') });

  // 最大化窗口
  await popup.click('#maximizeFooterBtn');
  const maxPage = await new Promise((resolvePage) => {
    const timer = setInterval(async () => {
      const pages = await browser.pages();
      const page = pages.find((p) => p.url().includes('app.html?window=1'));
      if (page) {
        clearInterval(timer);
        resolvePage(page);
      }
    }, 200);
    setTimeout(() => { clearInterval(timer); resolvePage(null); }, 8000);
  });
  if (!maxPage) throw new Error('maximized window not opened');
  await maxPage.waitForSelector('body.maximized', { timeout: 10000 });
  const maxTitle = await maxPage.$eval('h1', (el) => el.textContent.trim());
  console.log('maximized title:', maxTitle);
  await maxPage.screenshot({ path: resolve(screenshotDir, 'app-maximized.png') });

  // 划词换算
  const page = await browser.newPage();
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`content console: ${msg.text()}`);
  });
  page.on('pageerror', (err) => errors.push(`content pageerror: ${err.message}`));
  await page.goto('http://127.0.0.1:8766/');
  await page.evaluate(() => {
    const node = document.getElementById('dim');
    const range = document.createRange();
    range.selectNodeContents(node);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.dispatchEvent(new Event('selectionchange'));
  });
  await page.waitForSelector('#hunit-select-chip:not([hidden])', { timeout: 8000 });
  await page.click('#hunit-select-chip');
  await page.waitForFunction(() => !document.querySelector('#hunit-tooltip')?.hidden && document.querySelector('#hunit-tooltip .hunit-tooltip-text')?.textContent.includes('长'), { timeout: 10000 });
  console.log('tooltip OK');
  await page.screenshot({ path: resolve(screenshotDir, 'content-tooltip.png') });

  if (errors.length) {
    console.error('Console errors:\n' + errors.join('\n'));
    process.exitCode = 1;
  } else {
    console.log('UI test passed');
  }
} finally {
  if (browser) await browser.close();
  server.close();
}
