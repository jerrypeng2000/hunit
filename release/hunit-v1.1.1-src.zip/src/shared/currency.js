import { getSettings } from './storage.js';

export const CURRENCIES = ['USD', 'CNY', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD'];
export const CURRENCY_SYMBOLS = { USD: '$', CNY: '¥', EUR: '€', GBP: '£', JPY: '¥', AUD: 'A$', CAD: 'C$' };
export const DEFAULT_RATES = { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 };

const API_URL = 'https://open.er-api.com/v6/latest/USD';
const CACHE_MS = 10 * 60 * 1000;
const CACHE_KEY = 'hunit_rates';

export function pickRates(all) {
  const out = { USD: 1 };
  for (const c of CURRENCIES) {
    if (c === 'USD') continue;
    const v = Number(all[c]);
    if (Number.isFinite(v) && v > 0) out[c] = v;
  }
  return out;
}

export function hasManualRates(rates) {
  if (!rates) return false;
  const picked = pickRates(rates);
  return Object.keys(picked).length >= 2;
}

export function effectiveRates(settings) {
  if (settings.manualRatesEnabled && hasManualRates(settings.manualRates)) {
    return { ...DEFAULT_RATES, ...pickRates(settings.manualRates) };
  }
  return { ...DEFAULT_RATES };
}

export async function getRates() {
  const settings = await getSettings();
  if (settings.manualRatesEnabled && hasManualRates(settings.manualRates)) {
    return {
      rates: { ...DEFAULT_RATES, ...pickRates(settings.manualRates) },
      source: 'manual',
      updatedAt: Date.now()
    };
  }

  const cached = await chrome.storage.local.get({ [CACHE_KEY]: null });
  const cache = cached[CACHE_KEY];
  if (cache && cache.rates && Date.now() - (cache.updatedAt || 0) < CACHE_MS) {
    return { rates: cache.rates, source: 'cache', updatedAt: cache.updatedAt };
  }

  try {
    const resp = await fetch(API_URL);
    const json = await resp.json();
    if (json && json.result === 'success' && json.rates) {
      const rates = pickRates(json.rates);
      const payload = { rates, updatedAt: Date.now() };
      await chrome.storage.local.set({ [CACHE_KEY]: payload });
      return { rates, source: 'live', updatedAt: payload.updatedAt };
    }
  } catch (err) {
    console.warn('HUnit rate fetch failed', err);
  }

  if (cache && cache.rates) {
    return { rates: cache.rates, source: 'cache', updatedAt: cache.updatedAt || 0 };
  }
  return { rates: effectiveRates(settings), source: 'fallback', updatedAt: 0 };
}

export function convertCurrency(amount, from, to, rates) {
  if (!rates[from] || !rates[to]) return null;
  return Number(amount) * (Number(rates[to]) / Number(rates[from]));
}

export function formatUpdated(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
