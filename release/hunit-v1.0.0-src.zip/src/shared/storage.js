export const DEFAULT_SETTINGS = {
  baseUrl: 'https://ajkapi.9zos.com',
  appSlug: 'hunit',
  appId: 0,
  accessToken: '',
  userId: 0,
  theme: 'auto',
  dimensionMode: '1d',
  scenario: 'listing',
  defaultUnit: 'cm',
  defaultCurrency: 'CNY',
  precision: 2,
  divisor: 5000,
  manualRates: { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 },
  manualRatesEnabled: false
};

export async function getSettings() {
  const data = await chrome.storage.sync.get({ settings: DEFAULT_SETTINGS });
  return { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
}

export async function saveSettings(settings) {
  const merged = { ...DEFAULT_SETTINGS, ...settings };
  await chrome.storage.sync.set({ settings: merged });
  return merged;
}

export function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export async function getLocalQuota() {
  const data = await chrome.storage.local.get({ hunit_local_quota: { date: todayKey(), used: 0 } });
  const quota = data.hunit_local_quota || { date: todayKey(), used: 0 };
  if (quota.date !== todayKey()) {
    return { date: todayKey(), used: 0 };
  }
  return quota;
}

export async function setLocalQuota(quota) {
  await chrome.storage.local.set({ hunit_local_quota: quota });
}

export async function incrementLocalUsageCount() {
  const quota = await getLocalQuota();
  quota.used += 1;
  await setLocalQuota(quota);
  return quota.used;
}

export async function getCommonItems() {
  const data = await chrome.storage.local.get({ hunit_common_items: [] });
  return Array.isArray(data.hunit_common_items) ? data.hunit_common_items : [];
}

export async function saveCommonItems(items) {
  await chrome.storage.local.set({ hunit_common_items: items });
  return items;
}

export async function upsertCommonItem(item) {
  const items = await getCommonItems();
  const idx = items.findIndex((it) => it.id === item.id);
  if (idx >= 0) {
    items[idx] = item;
  } else {
    items.unshift(item);
  }
  await saveCommonItems(items);
  return items;
}

export async function removeCommonItem(id) {
  const items = await getCommonItems();
  const next = items.filter((it) => it.id !== id);
  await saveCommonItems(next);
  return next;
}

export async function getHistory() {
  const data = await chrome.storage.local.get({ hunit_history: [] });
  return Array.isArray(data.hunit_history) ? data.hunit_history : [];
}

export async function addHistory(entry) {
  const history = await getHistory();
  const item = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type: entry.type || 'dimension',
    input: entry.input || {},
    output: entry.output || '',
    timestamp: Date.now()
  };
  const next = [item, ...history].slice(0, 200);
  await chrome.storage.local.set({ hunit_history: next });
  return next;
}

export async function clearHistory() {
  await chrome.storage.local.set({ hunit_history: [] });
}

export async function getFavorites() {
  const data = await chrome.storage.local.get({ hunit_favorites: [] });
  return Array.isArray(data.hunit_favorites) ? data.hunit_favorites : [];
}

export async function toggleFavorite(entry) {
  const favorites = await getFavorites();
  const exists = favorites.find((it) => it.id === entry.id);
  let next;
  if (exists) {
    next = favorites.filter((it) => it.id !== entry.id);
  } else {
    next = [
      { ...entry, id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, timestamp: Date.now() },
      ...favorites
    ].slice(0, 100);
  }
  await chrome.storage.local.set({ hunit_favorites: next });
  return next;
}
