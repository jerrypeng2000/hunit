import { getEntitlement, consumeUsage, subscribeMonthly } from './shared/api.js';
import { getSettings } from './shared/storage.js';
import { convertDimensions, convertWeight, formatNumber, formatFlex, toGram, fromGram, LENGTH_UNITS, WEIGHT_UNITS } from './shared/convert.js';
import { parseDimensionText } from './shared/parser.js';
import { getRates, convertCurrency, CURRENCIES, CURRENCY_SYMBOLS, formatUpdated } from './shared/currency.js';
import { getCommonItems, addHistory, toggleFavorite, getFavorites } from './shared/storage.js';

const $ = (id) => document.getElementById(id);

let entitlement = null;
let settings = null;
let ratesInfo = null;
let currentFavoriteId = null;
let dimTimer = 0;

const QUICK_1D = [
  { label: '0.25m', value: 0.25, unit: 'm' },
  { label: '0.5m', value: 0.5, unit: 'm' },
  { label: '1m', value: 1, unit: 'm' },
  { label: '2m', value: 2, unit: 'm' },
  { label: '3m', value: 3, unit: 'm' },
  { label: '6ft', value: 6, unit: 'ft' },
  { label: '10ft', value: 10, unit: 'ft' }
];

const QUICK_WEIGHT = [
  { label: '50g', value: 50, unit: 'g' },
  { label: '100g', value: 100, unit: 'g' },
  { label: '200g', value: 200, unit: 'g' },
  { label: '500g', value: 500, unit: 'g' },
  { label: '1000g', value: 1000, unit: 'g' },
  { label: '1lb', value: 1, unit: 'lb' },
  { label: '2lb', value: 2, unit: 'lb' },
  { label: '3lb', value: 3, unit: 'lb' },
  { label: '5lb', value: 5, unit: 'lb' }
];

function applyTheme() {
  const theme = settings?.theme || 'auto';
  let resolved = theme;
  if (theme === 'auto') {
    resolved = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
}

function showStatus(text) {
  $('statusText').textContent = text;
}

function renderQuota() {
  if (!entitlement) return;
  const active = entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive || false;
  if (active) {
    $('quotaValue').textContent = '∞';
    $('quotaState').textContent = '会员不限次';
  } else {
    const remaining = entitlement.free_remaining_today ?? entitlement.freeRemainingToday ?? 0;
    $('quotaValue').textContent = remaining;
    $('quotaState').textContent = entitlement.local ? '本地模式' : '今日剩余';
  }
}

async function refreshEntitlement(silent = false) {
  if (!silent) showStatus('正在读取额度…');
  try {
    entitlement = await getEntitlement();
    renderQuota();
    renderCommonSelect();
    showStatus(entitlement.local ? '本地模式 · 未连接 AjkAPI' : '已连接 AjkAPI');
    if (isPro()) {
      $('priceLocked').classList.add('hidden');
    } else {
      $('priceLocked').classList.remove('hidden');
    }
  } catch (err) {
    showStatus(err?.message || '读取额度失败');
  }
}

function isPro() {
  return Boolean(entitlement && (entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive));
}

function showUpgrade(message) {
  $('upgradeMessage').textContent = message || '该功能需要 2 元/月会员。';
  $('upgradePanel').classList.remove('hidden');
}

function ensureCanUse(count = 1) {
  if (isPro()) return true;
  if (count > 1) {
    showUpgrade('批量换算需要付费会员');
    return false;
  }
  const remaining = entitlement?.free_remaining_today ?? 0;
  if (remaining <= 0) {
    showUpgrade('今日免费额度已用完');
    return false;
  }
  return true;
}

async function copyText(text, meta = {}) {
  if (!ensureCanUse(1)) return false;
  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  try {
    const result = await consumeUsage(1);
    if (!result.success) {
      showStatus(result.message || '额度不足');
      await refreshEntitlement(true);
      return false;
    }
    entitlement = {
      ...entitlement,
      plugin_monthly_active: result.plugin_monthly_active ?? entitlement.plugin_monthly_active,
      free_used_today: result.free_used_today ?? entitlement.free_used_today,
      free_remaining_today: result.free_remaining_today ?? Math.max(0, (entitlement.free_remaining_today ?? 1) - 1)
    };
    renderQuota();
    if (meta.type) {
      await addHistory({ type: meta.type, input: meta.input || {}, output: text });
    }
    showStatus('已复制 ✓');
    return true;
  } catch (err) {
    showStatus(err?.message || '计费失败');
    return false;
  }
}

/* ---------- 尺寸 ---------- */

function currentDimInputs() {
  return {
    mode: document.querySelector('#modeSeg .seg-btn.active').dataset.mode,
    scenario: document.querySelector('#scenarioSeg .seg-btn.active').dataset.scenario,
    unit: $('dimUnit').value,
    divisor: Number($('dimDivisor').value),
    length: Number($('dimLength').value || 0),
    width: Number($('dimWidth').value || 0),
    height: Number($('dimHeight').value || 0),
    weight: Number($('dimWeight').value || 0),
    weightUnit: $('dimWeightUnit').value
  };
}

function renderDimMode() {
  const { mode, scenario } = currentDimInputs();
  $('widthField').classList.toggle('dim-hidden', mode === '1d');
  $('heightField').classList.toggle('dim-hidden', mode !== '3d');
  $('divisorField').classList.toggle('dim-hidden', mode !== '3d');
  $('weightField').classList.toggle('dim-hidden', !(mode === '3d' && scenario === 'logistics'));

  const quick = $('quickChips');
  quick.innerHTML = '';
  if (mode === '1d') {
    for (const chip of QUICK_1D) {
      const btn = document.createElement('button');
      btn.className = 'quick-chip';
      btn.textContent = chip.label;
      btn.addEventListener('click', () => {
        $('dimLength').value = chip.value;
        $('dimUnit').value = chip.unit;
        renderDimension();
      });
      quick.appendChild(btn);
    }
  }
  renderDimension();
}

function renderDimension() {
  const { mode, scenario, unit, divisor, length, width, height, weight, weightUnit } = currentDimInputs();
  if (!length && !width && !height) {
    $('dimResult').hidden = true;
    return;
  }
  const weightGram = weight ? toGram(weight, weightUnit) : 0;
  const result = convertDimensions({
    mode,
    unit,
    divisor,
    length,
    width,
    height,
    precision: settings.precision,
    scenario,
    weightGram: scenario === 'logistics' ? weightGram : 0
  });

  const lines = $('dimLines');
  lines.innerHTML = '';
  for (const row of result.rows) {
    const line = document.createElement('div');
    line.className = 'result-line';
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = row.label;
    const value = document.createElement('span');
    value.className = 'value';
    const altText = row.altUnit && row.altUnit !== row.mainUnit
      ? ` / ${formatNumber(row.alt, settings.precision)} ${row.altUnit}`
      : '';
    value.textContent = `${formatNumber(row.main, settings.precision)} ${row.mainUnit}${altText}`;
    const copy = document.createElement('button');
    copy.textContent = '复制';
    copy.addEventListener('click', () => copyText(`${row.label} ${value.textContent}`, {
      type: 'dimension',
      input: { mode, unit, length, width, height }
    }));
    line.append(label, value, copy);
    lines.appendChild(line);
  }

  const listing = $('dimListing');
  if (scenario === 'listing' && result.listing) {
    listing.textContent = result.listing;
    listing.hidden = false;
    listing.onclick = () => copyText(result.listing, { type: 'dimension', input: { mode, unit, length, width, height } });
  } else {
    listing.hidden = true;
    listing.onclick = null;
  }

  $('copyCardBtn').onclick = () => copyText(result.cardText, { type: 'dimension', input: { mode, unit, length, width, height } });
  $('dimResult').hidden = false;
  updateFavoriteState({ mode, unit, length, width, height });
}

async function updateFavoriteState(input) {
  const favorites = await getFavorites();
  const key = JSON.stringify({ mode: input.mode, unit: input.unit, length: input.length, width: input.width, height: input.height });
  const found = favorites.find((it) => it.inputKey === key);
  currentFavoriteId = found ? found.id : null;
  $('favBtn').textContent = found ? '★ 已收藏' : '☆ 收藏';
}

$('favBtn').addEventListener('click', async () => {
  const input = currentDimInputs();
  if (!input.length && !input.width && !input.height) {
    showStatus('请先输入尺寸');
    return;
  }
  const key = JSON.stringify({ mode: input.mode, unit: input.unit, length: input.length, width: input.width, height: input.height });
  const entry = {
    id: currentFavoriteId || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    inputKey: key,
    name: `${input.length || 0}${input.unit} ${input.mode.toUpperCase()}`,
    mode: input.mode,
    unit: input.unit,
    length: input.length,
    width: input.width,
    height: input.height
  };
  await toggleFavorite(entry);
  showStatus(currentFavoriteId ? '已取消收藏' : '已收藏');
  await updateFavoriteState(input);
});

async function renderCommonSelect() {
  const items = await getCommonItems();
  const select = $('commonSelect');
  const previous = select.value;
  select.innerHTML = '<option value="">常用表（载入换算）</option>';
  const sorted = [...items].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (a.sortOrder || 0) - (b.sortOrder || 0));
  for (const item of sorted.slice(0, 50)) {
    const opt = document.createElement('option');
    opt.value = item.id;
    opt.textContent = `${item.pinned ? '★ ' : ''}${item.name || item.category || '未命名'}`;
    select.appendChild(opt);
  }
  if (previous && sorted.some((it) => it.id === previous)) {
    select.value = previous;
  }
}

$('loadCommonBtn').addEventListener('click', async () => {
  const id = $('commonSelect').value;
  if (!id) return;
  const items = await getCommonItems();
  const item = items.find((it) => it.id === id);
  if (!item) return;
  document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === item.mode));
  document.querySelectorAll('#scenarioSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.scenario === (item.scenario || 'listing')));
  $('dimUnit').value = item.unit || 'cm';
  $('dimLength').value = item.length || '';
  $('dimWidth').value = item.width || '';
  $('dimHeight').value = item.height || '';
  if (item.weightGram) {
    $('dimWeight').value = fromGram(item.weightGram, 'g');
    $('dimWeightUnit').value = 'g';
  }
  renderDimMode();
  showStatus(`已载入：${item.name || '常用项'}`);
});

function parsePaste() {
  const text = $('pasteInput').value.trim();
  if (!text) return;
  const parsed = parseDimensionText(text);
  if (!parsed) {
    showStatus('无法识别，支持 12x6x1、30*15*2cm、3.3ft、12"');
    return;
  }
  document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === parsed.mode));
  $('dimUnit').value = parsed.unit;
  $('dimLength').value = parsed.length;
  $('dimWidth').value = parsed.width || '';
  $('dimHeight').value = parsed.height || '';
  renderDimMode();
  showStatus(`已解析：${parsed.mode.toUpperCase()} · ${parsed.unit}`);
}

$('parseBtn').addEventListener('click', parsePaste);
$('pasteInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') parsePaste();
});

$('batchBtn').addEventListener('click', async () => {
  const lines = $('batchArea').value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (!lines.length) {
    $('batchStatus').textContent = '请先粘贴至少一行';
    return;
  }
  const parsed = lines.map((line) => ({ line, dim: parseDimensionText(line) })).filter((it) => it.dim);
  if (!parsed.length) {
    $('batchStatus').textContent = '没有识别到有效尺寸行';
    return;
  }
  if (!ensureCanUse(parsed.length)) {
    $('batchStatus').textContent = '批量换算需要会员';
    return;
  }
  const text = parsed.map((it) => {
    const result = convertDimensions({
      mode: it.dim.mode,
      unit: it.dim.unit,
      length: it.dim.length,
      width: it.dim.width || 0,
      height: it.dim.height || 0,
      divisor: settings.divisor,
      precision: settings.precision,
      scenario: settings.scenario
    });
    return `${it.line} => ${result.listing || result.cardText.split('\n')[0]}`;
  }).join('\n');

  try {
    const result = await consumeUsage(parsed.length);
    if (!result.success) {
      $('batchStatus').textContent = result.message || '额度不足';
      await refreshEntitlement(true);
      return;
    }
    await navigator.clipboard.writeText(text);
    entitlement = {
      ...entitlement,
      plugin_monthly_active: result.plugin_monthly_active ?? entitlement.plugin_monthly_active,
      free_remaining_today: result.free_remaining_today ?? Math.max(0, (entitlement.free_remaining_today ?? 0) - parsed.length)
    };
    renderQuota();
    await addHistory({ type: 'batch', input: { count: parsed.length }, output: text });
    $('batchStatus').textContent = `已换算 ${parsed.length} 行并复制 ✓`;
  } catch (err) {
    $('batchStatus').textContent = err?.message || '批量换算失败';
  }
});

/* ---------- 重量 ---------- */

function renderWeight() {
  const value = Number($('wValue').value || 0);
  if (!value) {
    $('wResult').hidden = true;
    return;
  }
  const unit = $('wUnit').value;
  const result = convertWeight(value, unit, settings.precision);
  const lines = $('wLines');
  lines.innerHTML = '';
  for (const row of result.rows) {
    const line = document.createElement('div');
    line.className = 'result-line';
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = row.label;
    const val = document.createElement('span');
    val.className = 'value';
    val.textContent = formatNumber(row.value, settings.precision);
    const copy = document.createElement('button');
    copy.textContent = '复制';
    copy.addEventListener('click', () => copyText(`${formatNumber(row.value, settings.precision)} ${row.label}`, {
      type: 'weight',
      input: { value, unit }
    }));
    line.append(label, val, copy);
    lines.appendChild(line);
  }
  $('wResult').hidden = false;
  $('wCopyBtn').onclick = () => copyText(result.rows.map((r) => `${formatNumber(r.value, settings.precision)} ${r.label}`).join('\n'), {
    type: 'weight',
    input: { value, unit }
  });
}

function renderWQuick() {
  const quick = $('wQuick');
  quick.innerHTML = '';
  for (const chip of QUICK_WEIGHT) {
    const btn = document.createElement('button');
    btn.className = 'quick-chip';
    btn.textContent = chip.label;
    btn.addEventListener('click', () => {
      $('wValue').value = chip.value;
      $('wUnit').value = chip.unit;
      renderWeight();
    });
    quick.appendChild(btn);
  }
}

/* ---------- 汇率 ---------- */

function renderCurrencySelects() {
  const from = $('curFrom');
  const to = $('curTo');
  from.innerHTML = '';
  to.innerHTML = '';
  for (const c of CURRENCIES) {
    const label = `${c} ${CURRENCY_SYMBOLS[c]}`;
    const optF = document.createElement('option');
    optF.value = c;
    optF.textContent = label;
    from.appendChild(optF);
    const optT = document.createElement('option');
    optT.value = c;
    optT.textContent = label;
    to.appendChild(optT);
  }
  from.value = settings.defaultCurrency || 'CNY';
  to.value = from.value === 'USD' ? 'CNY' : 'USD';
}

function renderCurrency() {
  if (!ratesInfo) return;
  const amount = Number($('curAmount').value || 0);
  const from = $('curFrom').value;
  const to = $('curTo').value;
  const sourceLabel = { live: '实时', cache: '缓存', manual: '手动', fallback: '内置' }[ratesInfo.source] || ratesInfo.source;
  $('rateStatus').textContent = `数据来源：${sourceLabel} · 更新：${formatUpdated(ratesInfo.updatedAt)} · 1 ${from} = ${formatFlex(convertCurrency(1, from, to, ratesInfo.rates), 4)} ${to}`;
  if (!amount) {
    $('curResultCard').hidden = true;
    return;
  }
  const value = convertCurrency(amount, from, to, ratesInfo.rates);
  if (value === null) {
    $('curResultCard').hidden = true;
    return;
  }
  $('curResult').textContent = `${formatNumber(value, 2)} ${to}`;
  $('curResultCard').hidden = false;
  $('curCopyBtn').onclick = () => copyText(`${formatNumber(value, 2)} ${to}`, {
    type: 'currency',
    input: { amount, from, to }
  });
}

/* ---------- 定价 ---------- */

function renderPrice() {
  if (!isPro()) return;
  const cost = Number($('priceCost').value || 0);
  const profit = Number($('priceProfit').value || 0) / 100;
  const commission = Number($('priceCommission').value || 0) / 100;
  const rate = Number($('priceRate').value || 0);
  if (!cost || !rate) {
    $('priceResultCard').hidden = true;
    return;
  }
  const costUsd = cost / rate;
  const priceUsd = costUsd * (1 + profit) / (1 - commission);
  const priceCny = priceUsd * rate;
  $('priceResult').textContent = `$${formatNumber(priceUsd, 2)}（¥${formatNumber(priceCny, 2)}）`;
  $('priceResultCard').hidden = false;
  $('priceCopyBtn').onclick = () => copyText(`成本 ¥${formatNumber(cost, 2)} · 目标利润 ${formatNumber(profit * 100, 0)}% · 佣金 ${formatNumber(commission * 100, 0)}%\n建议售价 $${formatNumber(priceUsd, 2)}（¥${formatNumber(priceCny, 2)}）`, {
    type: 'pricing',
    input: { cost, profit, commission, rate }
  });
}

/* ---------- 事件绑定 ---------- */

document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    $(`panel-${btn.dataset.tab}`).classList.add('active');
  });
});

document.querySelectorAll('#modeSeg .seg-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderDimMode();
  });
});

document.querySelectorAll('#scenarioSeg .seg-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#scenarioSeg .seg-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderDimMode();
  });
});

for (const id of ['dimLength', 'dimWidth', 'dimHeight', 'dimWeight']) {
  $(id).addEventListener('input', () => {
    clearTimeout(dimTimer);
    dimTimer = setTimeout(renderDimension, 120);
  });
}

for (const id of ['dimUnit', 'dimDivisor', 'dimWeightUnit']) {
  $(id).addEventListener('change', renderDimension);
}

$('wValue').addEventListener('input', renderWeight);
$('wUnit').addEventListener('change', renderWeight);
$('curAmount').addEventListener('input', renderCurrency);
$('curFrom').addEventListener('change', renderCurrency);
$('curTo').addEventListener('change', renderCurrency);
for (const id of ['priceCost', 'priceProfit', 'priceCommission', 'priceRate']) {
  $(id).addEventListener('input', renderPrice);
}

$('subscribeButton').addEventListener('click', async () => {
  const button = $('subscribeButton');
  const message = $('upgradeMessage');
  if (!settings.accessToken) {
    message.textContent = '请先在设置中连接 AjkAPI';
    chrome.runtime.openOptionsPage();
    return;
  }
  button.disabled = true;
  button.textContent = '正在开通…';
  try {
    await subscribeMonthly();
    await refreshEntitlement();
    $('upgradePanel').classList.add('hidden');
    $('priceLocked').classList.add('hidden');
    showStatus('会员开通成功');
  } catch (err) {
    message.textContent = err?.message || '开通失败，请检查 AjkAPI 连接和余额';
    showStatus('开通失败');
  } finally {
    button.disabled = false;
    button.textContent = '2 元/月，从余额开通';
  }
});

$('priceUpgradeBtn').addEventListener('click', () => {
  if (!settings.accessToken) {
    showStatus('请先在设置中连接 AjkAPI');
    chrome.runtime.openOptionsPage();
    return;
  }
  showUpgrade('开通后即可使用成本定价器。');
});

$('openOptionsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());
$('openOptionsUpgrade').addEventListener('click', () => chrome.runtime.openOptionsPage());

document.addEventListener('DOMContentLoaded', async () => {
  settings = await getSettings();
  applyTheme();
  renderCurrencySelects();
  renderWQuick();
  renderDimMode();
  ratesInfo = await getRates();
  renderCurrency();
  $('priceRate').value = formatFlex(convertCurrency(1, 'CNY', 'USD', ratesInfo.rates), 4);
  await refreshEntitlement();

  const pending = await chrome.storage.local.get({ hunit_pending_load: null });
  const pendingId = pending.hunit_pending_load;
  if (pendingId) {
    await chrome.storage.local.set({ hunit_pending_load: null });
    const items = await getCommonItems();
    const item = items.find((it) => it.id === pendingId);
    if (item) {
      document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === item.mode));
      document.querySelectorAll('#scenarioSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.scenario === (item.scenario || 'listing')));
      $('dimUnit').value = item.unit || 'cm';
      $('dimLength').value = item.length || '';
      $('dimWidth').value = item.width || '';
      $('dimHeight').value = item.height || '';
      if (item.weightGram) {
        $('dimWeight').value = fromGram(item.weightGram, 'g');
        $('dimWeightUnit').value = 'g';
      }
      renderDimMode();
      showStatus(`已载入：${item.name || '常用项'}`);
    }
  }
});
