import { getSettings, saveSettings } from './shared/storage.js';
import { testConnection, resolveAppId, getEntitlement } from './shared/api.js';
import { CURRENCIES, DEFAULT_RATES } from './shared/currency.js';
import {
  getCommonItems,
  upsertCommonItem,
  removeCommonItem,
  getHistory,
  clearHistory,
  getFavorites,
  toggleFavorite
} from './shared/storage.js';

const $ = (id) => document.getElementById(id);
const FREE_LIMIT = 10;
let settings = null;
let entitlement = null;
let editingId = null;

function applyTheme() {
  const theme = settings?.theme || 'auto';
  let resolved = theme;
  if (theme === 'auto') {
    resolved = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
}

function isPro() {
  return Boolean(entitlement && (entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive));
}

async function fillForm() {
  settings = await getSettings();
  $('baseUrl').value = settings.baseUrl || '';
  $('appSlug').value = settings.appSlug || '';
  $('appId').value = settings.appId || 0;
  $('accessToken').value = settings.accessToken || '';
  $('theme').value = settings.theme || 'auto';
  $('dimensionMode').value = settings.dimensionMode || '1d';
  $('scenario').value = settings.scenario || 'listing';
  $('defaultUnit').value = settings.defaultUnit || 'cm';
  $('divisor').value = String(settings.divisor || 5000);
  $('precision').value = String(settings.precision || 2);
  $('defaultCurrency').value = settings.defaultCurrency || 'CNY';
  $('manualRatesEnabled').checked = Boolean(settings.manualRatesEnabled);
  applyTheme();
  renderManualRates();
}

async function collectForm() {
  const manualRates = { ...DEFAULT_RATES };
  for (const c of CURRENCIES) {
    const v = Number($(`rate_${c}`)?.value);
    if (Number.isFinite(v) && v > 0) manualRates[c] = v;
  }
  return {
    baseUrl: $('baseUrl').value.trim().replace(/\/$/, ''),
    appSlug: $('appSlug').value.trim(),
    appId: Number($('appId').value || 0),
    accessToken: $('accessToken').value.trim(),
    theme: $('theme').value,
    dimensionMode: $('dimensionMode').value,
    scenario: $('scenario').value,
    defaultUnit: $('defaultUnit').value,
    divisor: Number($('divisor').value),
    precision: Number($('precision').value),
    defaultCurrency: $('defaultCurrency').value,
    manualRates,
    manualRatesEnabled: $('manualRatesEnabled').checked
  };
}

function renderManualRates() {
  const grid = $('manualRatesGrid');
  grid.innerHTML = '';
  const rates = settings.manualRates || DEFAULT_RATES;
  for (const c of CURRENCIES) {
    const label = document.createElement('label');
    label.textContent = `USD → ${c}`;
    const input = document.createElement('input');
    input.type = 'number';
    input.step = 'any';
    input.id = `rate_${c}`;
    input.value = rates[c] != null ? rates[c] : DEFAULT_RATES[c];
    label.appendChild(input);
    grid.appendChild(label);
  }
}

async function save() {
  try {
    const next = await collectForm();
    settings = await saveSettings(next);
    applyTheme();
    $('connectionResult').textContent = '已保存。';
  } catch (err) {
    $('connectionResult').textContent = err?.message || '保存失败';
  }
}

async function test() {
  try {
    const next = await collectForm();
    settings = await saveSettings(next);
    let resolved = await resolveAppId(settings);
    const info = await testConnection();
    entitlement = info;
    const active = info.plugin_monthly_active || info.pluginMonthlyActive;
    const remaining = info.free_remaining_today ?? info.freeRemainingToday ?? 0;
    $('connectionResult').textContent = `连接成功。App ID: ${resolved.appId || '未解析'}；${active ? '会员已开通' : `今日免费剩余 ${remaining} 次`}。`;
    renderPlan();
    await renderCommonList();
  } catch (err) {
    $('connectionResult').textContent = err?.message || '连接失败';
  }
}

async function refreshEntitlement() {
  try {
    entitlement = await getEntitlement();
  } catch (err) {
    entitlement = null;
  }
  renderPlan();
}

function renderPlan() {
  $('planBadge').textContent = isPro() ? '会员版' : '免费版';
  $('planBadge').classList.toggle('pro', isPro());
}

/* ---------- 常用表 ---------- */

function itemFormHtml(item) {
  item = item || {};
  return `
    <div class="grid-2">
      <label>名称<input id="f_name" value="${esc(item.name || '')}" placeholder="例如：手机壳 12cm" /></label>
      <label>分类<input id="f_category" value="${esc(item.category || '')}" placeholder="例如：3C" /></label>
      <label>标签<input id="f_tags" value="${esc((item.tags || []).join(','))}" placeholder="逗号分隔" /></label>
      <label>模式
        <select id="f_mode">
          <option value="1d" ${item.mode === '1d' ? 'selected' : ''}>1D 长度</option>
          <option value="2d" ${item.mode === '2d' ? 'selected' : ''}>2D 长×宽</option>
          <option value="3d" ${item.mode === '3d' ? 'selected' : ''}>3D 长×宽×高</option>
        </select>
      </label>
      <label>单位
        <select id="f_unit">
          ${['mm', 'cm', 'm', 'in', 'ft', 'yd'].map((u) => `<option value="${u}" ${item.unit === u ? 'selected' : ''}>${u}</option>`).join('')}
        </select>
      </label>
      <label>长<input id="f_length" type="number" step="any" value="${item.length || ''}" /></label>
      <label>宽<input id="f_width" type="number" step="any" value="${item.width || ''}" /></label>
      <label>高<input id="f_height" type="number" step="any" value="${item.height || ''}" /></label>
      <label>重量（克）<input id="f_weight" type="number" step="any" value="${item.weightGram || ''}" /></label>
      <label>备注<input id="f_note" value="${esc(item.note || '')}" /></label>
    </div>
    <label class="checkbox-row"><input id="f_pinned" type="checkbox" ${item.pinned ? 'checked' : ''} /> 置顶</label>
    <div class="actions">
      <button id="saveCommonBtn" class="primary-button">保存</button>
      <button id="cancelCommonBtn" class="secondary-button">取消</button>
    </div>
  `;
}

function esc(text) {
  return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function renderCommonList(filter = '') {
  const items = await getCommonItems();
  const list = $('commonList');
  const kw = (filter || '').trim().toLowerCase();
  const visible = items
    .filter((it) => {
      if (!kw) return true;
      return [it.name, it.category, (it.tags || []).join(' '), it.note].join(' ').toLowerCase().includes(kw);
    })
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (a.sortOrder || 0) - (b.sortOrder || 0));

  $('commonCount').textContent = `${items.length}/${isPro() ? '∞' : FREE_LIMIT}`;
  $('commonEmpty').classList.toggle('hidden', visible.length > 0);
  list.innerHTML = '';
  for (const item of visible) {
    const row = document.createElement('div');
    row.className = 'common-item';
    const main = document.createElement('div');
    main.className = 'main';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = `${item.pinned ? '★ ' : ''}${item.name || '未命名'}`;
    const meta = document.createElement('div');
    meta.className = 'meta';
    const dims = [item.length, item.width, item.height].filter((v) => v != null && v !== '').join(' x ');
    meta.textContent = `${item.category || '未分类'} · ${item.mode.toUpperCase()} · ${dims}${item.unit || ''}${item.weightGram ? ` · ${item.weightGram}g` : ''}`;
    const tags = document.createElement('div');
    tags.className = 'tags';
    tags.textContent = (item.tags || []).join('、');
    main.append(name, meta, tags);
    const actions = document.createElement('div');
    actions.className = 'item-actions';
    const loadBtn = document.createElement('button');
    loadBtn.textContent = '载入';
    loadBtn.addEventListener('click', () => loadItemToPopup(item));
    const pinBtn = document.createElement('button');
    pinBtn.textContent = item.pinned ? '取消置顶' : '置顶';
    pinBtn.addEventListener('click', async () => {
      await upsertCommonItem({ ...item, pinned: !item.pinned });
      await renderCommonList($('commonSearch').value);
    });
    const editBtn = document.createElement('button');
    editBtn.textContent = '编辑';
    editBtn.addEventListener('click', () => openForm(item));
    const delBtn = document.createElement('button');
    delBtn.className = 'danger';
    delBtn.textContent = '删除';
    delBtn.addEventListener('click', async () => {
      if (confirm(`删除“${item.name || '未命名'}”？`)) {
        await removeCommonItem(item.id);
        await renderCommonList($('commonSearch').value);
      }
    });
    actions.append(loadBtn, pinBtn, editBtn, delBtn);
    row.append(main, actions);
    list.appendChild(row);
  }
}

async function loadItemToPopup(item) {
  await chrome.storage.local.set({ hunit_pending_load: item.id });
  showResult('已发送到弹窗，打开换算通即可载入');
}

function openForm(item) {
  editingId = item ? item.id : null;
  const form = $('commonForm');
  form.classList.remove('hidden');
  form.innerHTML = itemFormHtml(item);
  $('saveCommonBtn').addEventListener('click', saveCommonForm);
  $('cancelCommonBtn').addEventListener('click', () => {
    form.classList.add('hidden');
    form.innerHTML = '';
    editingId = null;
  });
}

async function saveCommonForm() {
  const items = await getCommonItems();
  if (!editingId && !isPro() && items.length >= FREE_LIMIT) {
    showResult(`免费版最多 ${FREE_LIMIT} 条，开通会员可无限`);
    return;
  }
  const existing = items.find((it) => it.id === editingId) || {};
  const item = {
    ...existing,
    id: editingId || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: $('f_name').value.trim(),
    category: $('f_category').value.trim(),
    tags: $('f_tags').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
    mode: $('f_mode').value,
    unit: $('f_unit').value,
    length: Number($('f_length').value || 0),
    width: Number($('f_width').value || 0),
    height: Number($('f_height').value || 0),
    weightGram: Number($('f_weight').value || 0),
    note: $('f_note').value.trim(),
    pinned: $('f_pinned').checked,
    sortOrder: existing.sortOrder || items.length
  };
  await upsertCommonItem(item);
  $('commonForm').classList.add('hidden');
  $('commonForm').innerHTML = '';
  editingId = null;
  await renderCommonList($('commonSearch').value);
  showResult('已保存');
}

function exportJson() {
  getCommonItems().then((items) => downloadBlob(JSON.stringify(items, null, 2), 'hunit-common-items.json', 'application/json'));
}

function exportCsv() {
  getCommonItems().then((items) => {
    const header = ['name', 'category', 'tags', 'mode', 'unit', 'length', 'width', 'height', 'weightGram', 'note', 'pinned'];
    const rows = items.map((it) => header.map((h) => {
      const v = h === 'tags' ? (it.tags || []).join('|') : it[h];
      return `"${String(v ?? '').replace(/"/g, '""')}"`;
    }).join(','));
    downloadBlob([header.join(','), ...rows].join('\n'), 'hunit-common-items.csv', 'text/csv');
  });
}

function downloadBlob(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function importFile(file) {
  if (!isPro()) {
    showResult('导入导出为会员功能');
    return;
  }
  try {
    const text = await file.text();
    let items;
    if (file.name.endsWith('.json')) {
      items = JSON.parse(text);
      if (!Array.isArray(items)) throw new Error('JSON 格式错误');
    } else {
      items = parseCsv(text);
    }
    const current = await getCommonItems();
    const next = [...current];
    for (const raw of items) {
      const item = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: String(raw.name || raw['名称'] || '未命名'),
        category: String(raw.category || raw['分类'] || ''),
        tags: Array.isArray(raw.tags) ? raw.tags : String(raw.tags || '').split(/[|,，]/).filter(Boolean),
        mode: ['1d', '2d', '3d'].includes(raw.mode) ? raw.mode : '1d',
        unit: raw.unit || 'cm',
        length: Number(raw.length || 0),
        width: Number(raw.width || 0),
        height: Number(raw.height || 0),
        weightGram: Number(raw.weightGram || 0),
        note: String(raw.note || ''),
        pinned: Boolean(raw.pinned),
        sortOrder: next.length
      };
      next.push(item);
    }
    await chrome.storage.local.set({ hunit_common_items: next });
    await renderCommonList($('commonSearch').value);
    showResult(`导入 ${items.length} 条`);
  } catch (err) {
    showResult(`导入失败：${err?.message || err}`);
  }
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (!lines.length) return [];
  const parseLine = (line) => {
    const out = [];
    let cur = '';
    let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQ && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQ = !inQ;
        }
      } else if (ch === ',' && !inQ) {
        out.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur);
    return out;
  };
  const headers = parseLine(lines[0]);
  return lines.slice(1).map((line) => {
    const vals = parseLine(line);
    const obj = {};
    headers.forEach((h, i) => {
      obj[h.trim()] = vals[i] != null ? vals[i].trim() : '';
    });
    return obj;
  });
}

/* ---------- 历史 / 收藏 ---------- */

async function renderHistory() {
  const history = await getHistory();
  const list = $('historyList');
  list.innerHTML = '';
  const typeLabel = { dimension: '尺寸', weight: '重量', currency: '汇率', pricing: '定价', batch: '批量' };
  for (const item of history.slice(0, 30)) {
    const row = document.createElement('div');
    row.className = 'history-item';
    const type = document.createElement('span');
    type.className = 'type';
    type.textContent = typeLabel[item.type] || item.type;
    const content = document.createElement('span');
    content.className = 'content';
    content.textContent = String(item.output || '').replace(/\n/g, ' | ');
    const time = document.createElement('span');
    time.className = 'time';
    time.textContent = new Date(item.timestamp).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    row.append(type, content, time);
    list.appendChild(row);
  }
}

async function renderFavorites() {
  const favorites = await getFavorites();
  const list = $('favoritesList');
  list.innerHTML = '';
  for (const item of favorites.slice(0, 30)) {
    const row = document.createElement('div');
    row.className = 'history-item';
    const type = document.createElement('span');
    type.className = 'type';
    type.textContent = item.mode ? item.mode.toUpperCase() : '收藏';
    const content = document.createElement('span');
    content.className = 'content';
    const dims = [item.length, item.width, item.height].filter((v) => v != null && v !== '').join(' x ');
    content.textContent = `${item.name || '未命名'} · ${dims}${item.unit || ''}`;
    const actions = document.createElement('span');
    actions.className = 'item-actions';
    const del = document.createElement('button');
    del.textContent = '删除';
    del.addEventListener('click', async () => {
      await toggleFavorite(item);
      await renderFavorites();
    });
    actions.appendChild(del);
    row.append(type, content, actions);
    list.appendChild(row);
  }
}

function showResult(text) {
  $('connectionResult').textContent = text;
}

/* ---------- 事件 ---------- */

$('saveSettings').addEventListener('click', save);
$('testConnection').addEventListener('click', test);
$('addCommonBtn').addEventListener('click', () => openForm(null));
$('exportJsonBtn').addEventListener('click', exportJson);
$('exportCsvBtn').addEventListener('click', exportCsv);
$('importFile').addEventListener('change', (e) => {
  if (e.target.files[0]) importFile(e.target.files[0]);
  e.target.value = '';
});
$('commonSearch').addEventListener('input', (e) => renderCommonList(e.target.value));
$('clearHistoryBtn').addEventListener('click', async () => {
  await clearHistory();
  await renderHistory();
});

document.addEventListener('DOMContentLoaded', async () => {
  await fillForm();
  await refreshEntitlement();
  await renderCommonList();
  await renderHistory();
  await renderFavorites();
});
