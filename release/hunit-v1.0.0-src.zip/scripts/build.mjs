import * as esbuild from 'esbuild';
import JavaScriptObfuscator from 'javascript-obfuscator';
import { cpSync, mkdirSync, readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = resolve(root, 'dist');
mkdirSync(dist, { recursive: true });

const entryPoints = ['src/background.js', 'src/popup.js', 'src/options.js', 'src/content.js'];

await esbuild.build({
  entryPoints: entryPoints.map((p) => resolve(root, p)),
  bundle: true,
  format: 'iife',
  target: ['chrome100'],
  outdir: dist,
  sourcemap: false,
  legalComments: 'none',
  logLevel: 'info'
});

for (const name of readdirSync(dist)) {
  if (!name.endsWith('.js')) continue;
  const file = resolve(dist, name);
  const source = readFileSync(file, 'utf8');
  const options = name === 'background.js'
    ? {
        compact: true,
        controlFlowFlattening: false,
        deadCodeInjection: false,
        identifierNamesGenerator: 'hexadecimal',
        renameGlobals: false,
        rotateStringArray: false,
        selfDefending: false,
        splitStrings: false,
        stringArray: false,
        transformObjectKeys: false,
        target: 'browser'
      }
    : {
        compact: true,
        controlFlowFlattening: true,
        controlFlowFlatteningThreshold: 0.75,
        deadCodeInjection: true,
        deadCodeInjectionThreshold: 0.35,
        identifierNamesGenerator: 'hexadecimal',
        renameGlobals: false,
        rotateStringArray: true,
        selfDefending: false,
        splitStrings: true,
        stringArray: true,
        stringArrayEncoding: ['base64'],
        stringArrayThreshold: 0.75,
        transformObjectKeys: true,
        target: 'browser'
      };
  const result = JavaScriptObfuscator.obfuscate(source, options);
  writeFileSync(file, result.getObfuscatedCode());
}

for (const file of ['manifest.json', 'src/popup.html', 'src/options.html', 'src/popup.css', 'src/options.css', 'src/content.css']) {
  const src = resolve(root, file);
  const dst = resolve(root, 'dist', file === 'manifest.json' ? 'manifest.json' : file.replace('src/', ''));
  if (existsSync(src)) {
    cpSync(src, dst);
  }
}

const iconSource = resolve(root, 'icons');
const iconDest = resolve(root, 'dist', 'icons');
if (existsSync(iconSource)) {
  cpSync(iconSource, iconDest, { recursive: true });
}

console.log('HUnit extension build complete:', dist);
