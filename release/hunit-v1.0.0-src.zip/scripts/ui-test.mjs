import puppeteer from 'puppeteer-core';
import http from 'node:http';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const screenshotDir = resolve(root, 'screenshots');
mkdirSync(screenshotDir, { recursive: true });

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>测试页</title></head><body><h1>商品包装</h1><p id="target">包装箱尺寸：<span id="dim">12x6x1</span>，重量 <span id="w">500g</span>，价格 <span id="c">$20</span>。</p></body></html>`);
});

await new Promise((resolveListen) => server.listen(8766, '127.0.0.1', resolveListen));

let browser;
const errors = [];
try {
  browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: false,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--window-position=-32000,-32000',
      `--disable-extensions-except=${dist}`,
      `--load-extension=${dist}`
    ],
    defaultViewport: { width: 1280, height: 900 }
  });

  await new Promise((r) => setTimeout(r, 2500));
  const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  console.log('extension id:', extensionId);

  const popup = await browser.newPage();
  popup.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`popup console: ${msg.text()}`);
  });
  popup.on('pageerror', (err) => errors.push(`popup pageerror: ${err.message}`));
  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => document.querySelector('#quotaValue')?.textContent.trim() !== '—', { timeout: 10000 });
  const title = await popup.$eval('h1', (el) => el.textContent.trim());
  if (title !== '换算通 HUnit') throw new Error(`popup title unexpected: ${title}`);
  console.log('popup title OK, quota:', await popup.$eval('#quotaValue', (el) => el.textContent.trim()));

  await popup.select('#dimUnit', 'in');
  await popup.click('#modeSeg [data-mode="3d"]');
  await popup.type('#dimLength', '12');
  await popup.type('#dimWidth', '6');
  await popup.type('#dimHeight', '1');
  await new Promise((r) => setTimeout(r, 400));
  const lines = await popup.$$eval('#dimLines .result-line', (els) => els.map((el) => el.textContent.trim()));
  console.log('dim lines:', lines.join(' | '));
  const joined = lines.join(' | ');
  if (!joined.includes('30.48 cm')) throw new Error('expected 30.48 cm in length row');
  if (!joined.includes('72.00 in³')) throw new Error('expected volume row');
  if (!joined.includes('0.24 kg')) throw new Error('expected volumetric weight row');
  await popup.screenshot({ path: resolve(screenshotDir, 'popup.png') });

  const options = await browser.newPage();
  options.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`options console: ${msg.text()}`);
  });
  options.on('pageerror', (err) => errors.push(`options pageerror: ${err.message}`));
  await options.goto(`chrome-extension://${extensionId}/options.html`);
  await options.waitForSelector('#baseUrl');
  await new Promise((r) => setTimeout(r, 800));
  await options.screenshot({ path: resolve(screenshotDir, 'options.png') });

  const page = await browser.newPage();
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`content console: ${msg.text()}`);
  });
  page.on('pageerror', (err) => errors.push(`content pageerror: ${err.message}`));
  await page.goto('http://127.0.0.1:8766/');
  await page.evaluate(() => {
    const node = document.getElementById('dim');
    const range = document.createRange();
    range.selectNodeContents(node);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    document.dispatchEvent(new Event('selectionchange'));
  });
  await page.waitForSelector('#hunit-select-chip:not([hidden])', { timeout: 8000 });
  await page.screenshot({ path: resolve(screenshotDir, 'content-chip.png') });
  await page.click('#hunit-select-chip');
  await page.waitForFunction(() => !document.querySelector('#hunit-tooltip')?.hidden && document.querySelector('#hunit-tooltip .hunit-tooltip-text')?.textContent.includes('长'), { timeout: 10000 });
  const tooltipText = await page.$eval('#hunit-tooltip .hunit-tooltip-text', (el) => el.textContent);
  console.log('tooltip:', tooltipText.replace(/\n/g, ' | '));
  await page.screenshot({ path: resolve(screenshotDir, 'content-tooltip.png') });

  if (errors.length) {
    console.error('Console errors:\n' + errors.join('\n'));
    process.exitCode = 1;
  } else {
    console.log('UI test passed');
  }
} finally {
  if (browser) await browser.close();
  server.close();
}
