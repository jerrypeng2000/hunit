# 换算通 HUnit

面向跨境电商从业者的浏览器扩展：长度、长×宽、长×宽×高三种维度，加上重量、汇率和成本定价，一站式换算，输出可直接粘贴到 Amazon / eBay / 独立站的上架格式。

## 免费版

- 每天 10 次换算
- 1D / 2D / 3D 基础换算
- 重量换算 g / kg / lb / oz
- 实时汇率、常用表（10 条）

## 付费版：2 元 / 月

- 不限次
- 成本定价器
- 手动汇率
- 常用表无限条
- 批量换算
- CSV / JSON 导入导出

付费从 AjkAPI 账号余额中扣除，默认 30 天有效。

## 支持的浏览器

- Google Chrome
- Microsoft Edge
- 360 安全浏览器 / 360 极速浏览器（Chromium 内核）

## 安装方法

1. 下载 `hunit-v1.0.0-chromium.zip`。
2. 解压到固定文件夹。
3. 打开浏览器扩展管理页：
   - Chrome：`chrome://extensions`
   - Edge：`edge://extensions`
4. 打开“开发者模式”。
5. 点击“加载已解压的扩展程序”，选择解压后的文件夹。
6. 固定扩展图标，按 `Alt+U` 或点击图标打开。

## 连接 AjkAPI

1. 打开扩展设置。
2. 保持服务器地址 `https://ajkapi.9zos.com`。
3. 应用标识填写 `hunit`。
4. 在 AjkAPI 控制台生成 Access Token，填入设置。
5. 点击“测试连接”。

未连接 AjkAPI 时，扩展会在本地试用模式下提供每天 10 次换算。

## 使用方法

### 尺寸换算

- 选择 1D（长度）/ 2D（长×宽）/ 3D（长×宽×高）模式；
- 输入即出结果，自动算面积、体积、体积重（除数可切换 5000 / 6000 / 139 / 166）；
- “上架格式”输出 `12 x 6 x 1 inches` 或 `30.5 x 15.2 x 2.5 cm`；
- 粘贴 `12x6x1`、`30*15*2cm`、`3.3ft`、`12"` 可自动解析；
- 批量换算：每行一个尺寸，会员可一次转换多行。

### 重量 / 汇率 / 定价

- 重量：g / kg / lb / oz 双向换算；
- 汇率：USD / CNY / EUR / GBP / JPY / AUD / CAD，实时汇率缓存 10 分钟，异常时使用缓存；
- 定价：输入成本、目标利润、平台佣金，自动计算建议售价（会员）。

### 划词与右键

- 网页中选中 `12cm`、`3.5in`、`500g`、`$20` 等文字会出现“换算”按钮；
- 右键菜单“用换算通 HUnit 换算选中内容”直接出结果。

## 从源码构建

```bash
npm install
npm run build
```

构建产物在 `dist/`，已混淆。

## 项目结构

```text
extension/
  manifest.json
  src/
    background.js
    popup.html/css/js
    options.html/css/js
    content.js/css
    shared/
  scripts/
    build.mjs
    generate_icons.py
  dist/
```

## 隐私说明

- 所有单位、面积、体积、体积重计算都在本地完成；
- 只有额度、会员和计费信息会调用 AjkAPI；
- 汇率通过公开接口获取，不上传换算内容。
