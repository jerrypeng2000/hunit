import { getEntitlement, consumeUsage, subscribeMonthly, unsubscribeMonthly, resolveAppId } from './shared/api.js';
import { getSettings, saveSettings } from './shared/storage.js';
import { convertDimensions, convertWeight, formatNumber, formatFlex, toGram, fromGram, LENGTH_UNITS, WEIGHT_UNITS } from './shared/convert.js';
import { parseDimensionText } from './shared/parser.js';
import { getRates, convertCurrency, CURRENCIES, CURRENCY_SYMBOLS, DEFAULT_RATES, formatUpdated } from './shared/currency.js';
import { searchHs, hsDetail } from './shared/hs.js';
import {
  getCommonItems,
  addCommonItem,
  upsertCommonItem,
  removeCommonItem,
  addHistory,
  toggleFavorite,
  getFavorites,
  clearHistory
} from './shared/storage.js';

const $ = (id) => document.getElementById(id);

window.__HUNIT_APP_LOADED__ = true;
window.addEventListener('error', (e) => {
  try {
    const el = document.getElementById('statusText');
    if (el) el.textContent = `错误：${e.message || '未知错误'}`;
  } catch (_) {}
});

const params = new URLSearchParams(location.search);
const IS_MAXIMIZED = params.get('window') === '1';

let entitlement = null;
let settings = null;
let ratesInfo = null;
let currentFavoriteId = null;
let dimTimer = 0;
let commonEditingId = null;
let hsRows = [];
let hsSelected = null;
let hsDetailData = null;

const QUICK_1D = [
  { label: '0.25m', value: 0.25, unit: 'm' },
  { label: '0.5m', value: 0.5, unit: 'm' },
  { label: '1m', value: 1, unit: 'm' },
  { label: '2m', value: 2, unit: 'm' },
  { label: '3m', value: 3, unit: 'm' },
  { label: '6ft', value: 6, unit: 'ft' },
  { label: '10ft', value: 10, unit: 'ft' }
];

const QUICK_WEIGHT = [
  { label: '50g', value: 50, unit: 'g' },
  { label: '100g', value: 100, unit: 'g' },
  { label: '200g', value: 200, unit: 'g' },
  { label: '500g', value: 500, unit: 'g' },
  { label: '1000g', value: 1000, unit: 'g' },
  { label: '1lb', value: 1, unit: 'lb' },
  { label: '2lb', value: 2, unit: 'lb' },
  { label: '3lb', value: 3, unit: 'lb' },
  { label: '5lb', value: 5, unit: 'lb' }
];

const TYPE_LABELS = { dimension: '尺寸', weight: '重量', currency: '汇率', pricing: '定价', hs: '海关编码', result: '单值' };

function applyTheme() {
  const theme = settings?.theme || 'auto';
  let resolved = theme;
  if (theme === 'auto') {
    resolved = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.documentElement.dataset.theme = resolved;
  document.documentElement.style.colorScheme = resolved;
}

function showStatus(text) {
  $('statusText').textContent = text;
}

function renderQuota() {
  if (!entitlement) return;
  const active = isPro();
  if (active) {
    $('quotaValue').textContent = '∞';
    $('quotaState').textContent = '会员不限次';
  } else {
    const remaining = entitlement.free_remaining_today ?? entitlement.freeRemainingToday ?? 0;
    $('quotaValue').textContent = remaining;
    $('quotaState').textContent = entitlement.local ? '本地模式' : '今日剩余';
  }
}

function isPro() {
  return Boolean(entitlement && (entitlement.plugin_monthly_active || entitlement.pluginMonthlyActive));
}

function formatDate(ts) {
  if (!ts) return '—';
  const d = new Date(Number(ts) * 1000);
  if (Number.isNaN(d.getTime())) return '—';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function renderMembership() {
  if (!entitlement) return;
  const active = isPro();
  const cancelled = entitlement.plugin_monthly_cancelled || entitlement.pluginMonthlyCancelled || false;
  const endAt = entitlement.plugin_monthly_end_at || entitlement.pluginMonthlyEndAt || 0;
  const status = $('membershipStatus');
  if (!active) {
    status.textContent = `免费版 · 今日剩余 ${entitlement.free_remaining_today ?? 0} 次`;
    $('subscribeButton').classList.remove('hidden');
    $('subscribeButton').textContent = '2 元/月，从余额开通';
    $('unsubscribeButton').classList.add('hidden');
  } else if (cancelled) {
    status.textContent = `已退订 · 会员服务至 ${formatDate(endAt)}（到期后恢复免费版）`;
    $('subscribeButton').classList.remove('hidden');
    $('subscribeButton').textContent = '重新开通包月';
    $('unsubscribeButton').classList.add('hidden');
  } else {
    status.textContent = `会员已开通 · 有效期至 ${formatDate(endAt)}`;
    $('subscribeButton').classList.add('hidden');
    $('unsubscribeButton').classList.remove('hidden');
  }
}

async function refreshEntitlement(silent = false) {
  if (!silent) showStatus('正在读取额度…');
  try {
    entitlement = await getEntitlement();
    renderQuota();
    renderMembership();
    showStatus(entitlement.local ? '本地模式 · 未连接 AjkAPI' : '已连接 AjkAPI');
  } catch (err) {
    showStatus(err?.message || '读取额度失败');
  }
}

function showUpgrade(message) {
  $('upgradeMessage').textContent = message || '该功能需要 2 元/月会员。';
  renderMembership();
  $('upgradePanel').classList.remove('hidden');
}

function ensureCanUse(count = 1) {
  if (isPro()) return true;
  if (count > 1) {
    showUpgrade('批量换算需要付费会员');
    return false;
  }
  const remaining = entitlement?.free_remaining_today ?? 0;
  if (remaining <= 0) {
    showUpgrade('今日免费额度已用完');
    return false;
  }
  return true;
}

async function copyText(text, meta = {}) {
  if (!ensureCanUse(1)) return false;
  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
  try {
    const result = await consumeUsage(1);
    if (!result.success) {
      showStatus(result.message || '额度不足');
      await refreshEntitlement(true);
      return false;
    }
    entitlement = {
      ...entitlement,
      plugin_monthly_active: result.plugin_monthly_active ?? entitlement.plugin_monthly_active,
      free_used_today: result.free_used_today ?? entitlement.free_used_today,
      free_remaining_today: result.free_remaining_today ?? Math.max(0, (entitlement.free_remaining_today ?? 1) - 1)
    };
    renderQuota();
    if (meta.type) {
      await addHistory({ type: meta.type, input: meta.input || {}, output: text });
    }
    showStatus('已复制 ✓');
    return true;
  } catch (err) {
    showStatus(err?.message || '计费失败');
    return false;
  }
}

/* ================= 尺寸 ================= */

function currentDimInputs() {
  return {
    mode: document.querySelector('#modeSeg .seg-btn.active').dataset.mode,
    scenario: document.querySelector('#scenarioSeg .seg-btn.active').dataset.scenario,
    unit: $('dimUnit').value,
    divisor: Number($('dimDivisor').value),
    length: Number($('dimLength').value || 0),
    width: Number($('dimWidth').value || 0),
    height: Number($('dimHeight').value || 0),
    weight: Number($('dimWeight').value || 0),
    weightUnit: $('dimWeightUnit').value
  };
}

function renderDimMode() {
  const { mode, scenario } = currentDimInputs();
  $('widthField').classList.toggle('dim-hidden', mode === '1d');
  $('heightField').classList.toggle('dim-hidden', mode !== '3d');
  $('divisorField').classList.toggle('dim-hidden', mode !== '3d');
  $('weightField').classList.toggle('dim-hidden', !(mode === '3d' && scenario === 'logistics'));

  const quick = $('quickChips');
  quick.innerHTML = '';
  if (mode === '1d') {
    for (const chip of QUICK_1D) {
      const btn = document.createElement('button');
      btn.className = 'quick-chip';
      btn.textContent = chip.label;
      btn.addEventListener('click', () => {
        $('dimLength').value = chip.value;
        $('dimUnit').value = chip.unit;
        renderDimension();
      });
      quick.appendChild(btn);
    }
  }
  renderDimension();
}

function renderDimension() {
  const { mode, scenario, unit, divisor, length, width, height, weight, weightUnit } = currentDimInputs();
  if (!length && !width && !height) {
    $('dimResult').hidden = true;
    return;
  }
  const weightGram = weight ? toGram(weight, weightUnit) : 0;
  const result = convertDimensions({
    mode,
    unit,
    divisor,
    length,
    width,
    height,
    precision: settings.precision,
    scenario,
    weightGram: scenario === 'logistics' ? weightGram : 0
  });

  const lines = $('dimLines');
  lines.innerHTML = '';
  for (const row of result.rows) {
    const line = document.createElement('div');
    line.className = 'result-line';
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = row.label;
    const value = document.createElement('span');
    value.className = 'value';
    const altText = row.altUnit && row.altUnit !== row.mainUnit
      ? ` / ${formatNumber(row.alt, settings.precision)} ${row.altUnit}`
      : '';
    value.textContent = `${formatNumber(row.main, settings.precision)} ${row.mainUnit}${altText}`;
    const copy = document.createElement('button');
    copy.textContent = '复制';
    copy.addEventListener('click', () => copyText(`${row.label} ${value.textContent}`, {
      type: 'dimension',
      input: { mode, unit, length, width, height }
    }));
    const save = document.createElement('button');
    save.className = 'save-row-btn';
    save.textContent = '存';
    save.title = '单个结果加入常用表';
    save.addEventListener('click', () => addRowToCommon(row.label, value.textContent, row.kind || 'length'));
    line.append(label, value, copy, save);
    lines.appendChild(line);
  }

  const listing = $('dimListing');
  if (scenario === 'listing' && result.listing) {
    listing.textContent = result.listing;
    listing.hidden = false;
    listing.onclick = () => copyText(result.listing, { type: 'dimension', input: { mode, unit, length, width, height } });
  } else {
    listing.hidden = true;
    listing.onclick = null;
  }

  $('copyCardBtn').onclick = () => copyText(result.cardText, { type: 'dimension', input: { mode, unit, length, width, height } });
  $('dimResult').hidden = false;
  updateFavoriteState({ mode, unit, length, width, height });
}

async function updateFavoriteState(input) {
  const favorites = await getFavorites();
  const key = JSON.stringify({ mode: input.mode, unit: input.unit, length: input.length, width: input.width, height: input.height });
  const found = favorites.find((it) => it.inputKey === key);
  currentFavoriteId = found ? found.id : null;
  $('favBtn').textContent = found ? '★ 已收藏' : '☆ 收藏';
}

async function addRowToCommon(label, valueText, kind) {
  await addCommonItem({
    type: 'result',
    name: `${label} ${valueText}`.slice(0, 50),
    category: kind === 'weight' ? '重量' : '尺寸',
    label,
    output: `${label} ${valueText}`,
    kind
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
}

function parsePaste() {
  const text = $('pasteInput').value.trim();
  if (!text) return;
  const parsed = parseDimensionText(text);
  if (!parsed) {
    showStatus('无法识别，支持 12x6x1、30*15*2cm、3.3ft、12"');
    return;
  }
  document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === parsed.mode));
  $('dimUnit').value = parsed.unit;
  $('dimLength').value = parsed.length;
  $('dimWidth').value = parsed.width || '';
  $('dimHeight').value = parsed.height || '';
  renderDimMode();
  showStatus(`已解析：${parsed.mode.toUpperCase()} · ${parsed.unit}`);
}

async function addDimToCommon() {
  const input = currentDimInputs();
  if (!input.length && !input.width && !input.height) {
    showStatus('请先输入尺寸');
    return;
  }
  const dims = [input.length, input.width, input.height].filter((v) => v).join(' x ');
  const result = convertDimensions({
    mode: input.mode,
    unit: input.unit,
    divisor: input.divisor,
    length: input.length,
    width: input.width,
    height: input.height,
    precision: settings.precision,
    scenario: input.scenario
  });
  await addCommonItem({
    type: 'dimension',
    name: `${dims} ${input.unit}`,
    category: input.mode.toUpperCase(),
    output: result.listing || result.cardText.split('\n')[0],
    mode: input.mode,
    unit: input.unit,
    length: input.length,
    width: input.width,
    height: input.height,
    weightGram: input.weight ? toGram(input.weight, input.weightUnit) : 0,
    scenario: input.scenario
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
}

/* ================= 重量 ================= */

function renderWeight() {
  const value = Number($('wValue').value || 0);
  if (!value) {
    $('wResult').hidden = true;
    return;
  }
  const unit = $('wUnit').value;
  const result = convertWeight(value, unit, settings.precision);
  const lines = $('wLines');
  lines.innerHTML = '';
  for (const row of result.rows) {
    const line = document.createElement('div');
    line.className = 'result-line';
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = row.label;
    const val = document.createElement('span');
    val.className = 'value';
    val.textContent = formatNumber(row.value, settings.precision);
    const copy = document.createElement('button');
    copy.textContent = '复制';
    copy.addEventListener('click', () => copyText(`${formatNumber(row.value, settings.precision)} ${row.label}`, {
      type: 'weight',
      input: { value, unit }
    }));
    const save = document.createElement('button');
    save.className = 'save-row-btn';
    save.textContent = '存';
    save.title = '单个结果加入常用表';
    save.addEventListener('click', () => addRowToCommon(row.label, `${formatNumber(row.value, settings.precision)} ${row.label}`, 'weight'));
    line.append(label, val, copy, save);
    lines.appendChild(line);
  }
  $('wResult').hidden = false;
  $('wCopyBtn').onclick = () => copyText(result.rows.map((r) => `${formatNumber(r.value, settings.precision)} ${r.label}`).join('\n'), {
    type: 'weight',
    input: { value, unit }
  });
}

function renderWQuick() {
  const quick = $('wQuick');
  quick.innerHTML = '';
  for (const chip of QUICK_WEIGHT) {
    const btn = document.createElement('button');
    btn.className = 'quick-chip';
    btn.textContent = chip.label;
    btn.addEventListener('click', () => {
      $('wValue').value = chip.value;
      $('wUnit').value = chip.unit;
      renderWeight();
    });
    quick.appendChild(btn);
  }
}

/* ================= 汇率 ================= */

function renderCurrencySelects() {
  const from = $('curFrom');
  const to = $('curTo');
  from.innerHTML = '';
  to.innerHTML = '';
  for (const c of CURRENCIES) {
    const label = `${c} ${CURRENCY_SYMBOLS[c]}`;
    const optF = document.createElement('option');
    optF.value = c;
    optF.textContent = label;
    from.appendChild(optF);
    const optT = document.createElement('option');
    optT.value = c;
    optT.textContent = label;
    to.appendChild(optT);
  }
  from.value = settings.defaultCurrency || 'CNY';
  to.value = from.value === 'USD' ? 'CNY' : 'USD';
}

function renderCurrency() {
  if (!ratesInfo) return;
  const amount = Number($('curAmount').value || 0);
  const from = $('curFrom').value;
  const to = $('curTo').value;
  const sourceLabel = { live: '实时', cache: '缓存', manual: '手动', fallback: '内置' }[ratesInfo.source] || ratesInfo.source;
  $('rateStatus').textContent = `数据来源：${sourceLabel} · 更新：${formatUpdated(ratesInfo.updatedAt)} · 1 ${from} = ${formatFlex(convertCurrency(1, from, to, ratesInfo.rates), 4)} ${to}`;
  if (!amount) {
    $('curResultCard').hidden = true;
    return;
  }
  const value = convertCurrency(amount, from, to, ratesInfo.rates);
  if (value === null) {
    $('curResultCard').hidden = true;
    return;
  }
  $('curResult').textContent = `${formatNumber(value, 2)} ${to}`;
  $('curResultCard').hidden = false;
  $('curCopyBtn').onclick = () => copyText(`${formatNumber(value, 2)} ${to}`, {
    type: 'currency',
    input: { amount, from, to }
  });
}

/* ================= 定价 ================= */

function renderPrice() {
  const cost = Number($('priceCost').value || 0);
  const profit = Number($('priceProfit').value || 0) / 100;
  const commission = Number($('priceCommission').value || 0) / 100;
  const rate = Number($('priceRate').value || 0);
  if (!rate) {
    $('priceResultCard').hidden = true;
    return;
  }
  if (!cost) {
    $('priceResultCard').hidden = true;
    return;
  }
  const costUsd = cost / rate;
  const commissionAmount = commission >= 1 ? 0 : costUsd * (1 + profit) * (commission / (1 - commission));
  const priceUsd = commission >= 1 ? 0 : costUsd * (1 + profit) / (1 - commission);
  const priceCny = priceUsd * rate;
  $('priceResult').textContent = `$${formatNumber(priceUsd, 2)}（¥${formatNumber(priceCny, 2)}）`;
  $('priceBreakdown').innerHTML = [
    `成本（USD）<b>$${formatNumber(costUsd, 2)}</b>`,
    `平台佣金 <b>$${formatNumber(commissionAmount, 2)}</b>`,
    `目标利润 <b>$${formatNumber(priceUsd - costUsd - commissionAmount, 2)}</b>`,
    `到手净额 <b>$${formatNumber(priceUsd * (1 - commission), 2)}</b>`
  ].join(' · ');
  $('priceResultCard').hidden = false;
  $('priceCopyBtn').onclick = () => copyText(
    `成本 ¥${formatNumber(cost, 2)}（$${formatNumber(costUsd, 2)}）\n目标利润 ${formatNumber(profit * 100, 0)}% · 平台佣金 ${formatNumber(commission * 100, 0)}%\n建议售价 $${formatNumber(priceUsd, 2)}（¥${formatNumber(priceCny, 2)}）`,
    { type: 'pricing', input: { cost, profit, commission, rate } }
  );
}

async function addPriceToCommon() {
  const cost = Number($('priceCost').value || 0);
  if (!cost) {
    showStatus('请先输入采购成本');
    return;
  }
  const profit = Number($('priceProfit').value || 0) / 100;
  const commission = Number($('priceCommission').value || 0) / 100;
  const rate = Number($('priceRate').value || 0);
  const priceUsd = rate ? cost / rate * (1 + profit) / (1 - commission) : 0;
  const priceCny = priceUsd * rate;
  await addCommonItem({
    type: 'pricing',
    name: `定价 ¥${cost}`,
    category: '定价',
    output: `建议售价 $${formatNumber(priceUsd, 2)}（¥${formatNumber(priceCny, 2)}）`,
    cost,
    profit,
    commission,
    rate
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
}

/* ================= 海关编码 ================= */

async function runHsSearch() {
  const keyword = $('hsSearch').value.trim();
  if (!keyword) {
    $('hsStatus').textContent = '请输入商品关键词';
    return;
  }
  $('hsSearchBtn').disabled = true;
  $('hsStatus').textContent = '正在查询…';
  $('hsDetailCard').hidden = true;
  hsDetailData = null;
  hsSelected = null;
  try {
    hsRows = await searchHs(keyword);
    renderHsResults();
    $('hsStatus').textContent = hsRows.length ? `找到 ${hsRows.length} 条结果，点击可查看详情` : '未找到结果，换个关键词试试';
  } catch (err) {
    $('hsStatus').textContent = err?.message || '查询失败，请稍后重试';
  } finally {
    $('hsSearchBtn').disabled = false;
  }
}

function renderHsResults() {
  const list = $('hsResults');
  list.innerHTML = '';
  for (const row of hsRows) {
    const item = document.createElement('div');
    item.className = 'hs-item';
    const code = document.createElement('div');
    code.className = 'hs-code';
    code.textContent = row.code;
    const name = document.createElement('div');
    name.className = 'hs-name';
    name.textContent = row.name;
    const meta = document.createElement('div');
    meta.className = 'hs-meta';
    meta.textContent = [row.unit, row.rebate ? `退税率 ${row.rebate}` : '', row.regulatory ? `监管 ${row.regulatory}` : ''].filter(Boolean).join(' · ');
    const actions = document.createElement('div');
    actions.className = 'hs-actions';
    const copy = document.createElement('button');
    copy.textContent = '复制编码';
    copy.addEventListener('click', (e) => {
      e.stopPropagation();
      copyText(row.code, { type: 'hs', input: { code: row.code } });
    });
    const open = document.createElement('button');
    open.textContent = '原网页';
    open.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.tabs.create({ url: row.url });
    });
    actions.append(copy, open);
    item.append(code, name, meta, actions);
    item.addEventListener('click', () => loadHsDetail(row));
    list.appendChild(item);
  }
}

async function loadHsDetail(row) {
  document.querySelectorAll('.hs-item').forEach((el) => el.classList.remove('active'));
  const item = Array.from(document.querySelectorAll('.hs-item')).find((el) => el.querySelector('.hs-code')?.textContent === row.code);
  if (item) item.classList.add('active');
  hsSelected = row;
  $('hsStatus').textContent = '正在加载详情…';
  try {
    hsDetailData = await hsDetail(row.code);
    renderHsDetail(row);
    $('hsStatus').textContent = '详情已加载';
  } catch (err) {
    hsDetailData = null;
    renderHsDetail(row);
    $('hsStatus').textContent = '详情加载失败，仅显示搜索结果';
  }
}

function renderHsDetail(row) {
  const d = hsDetailData || {};
  $('hsDetailTitle').textContent = `${row.code} · ${d.name || row.name}`;
  const grid = $('hsDetailGrid');
  grid.innerHTML = '';
  const fields = [
    ['商品名称', d['商品名称'] || row.name],
    ['商品描述', d['商品描述']],
    ['计量单位', d['计量单位'] || row.unit],
    ['出口退税', d['出口退税税率'] || row.rebate],
    ['增值税率', d['增值税率']],
    ['最惠国税率', d['最惠国税率']],
    ['出口税率', d['出口税率']],
    ['消费税率', d['消费税率']],
    ['进口普通税率', d['进口普通税率']],
    ['编码状态', d['编码状态']],
    ['更新时间', d['更新时间']]
  ];
  for (const [k, v] of fields) {
    if (!v) continue;
    const div = document.createElement('div');
    div.className = 'hd';
    div.innerHTML = `<span class="k">${k}</span><span class="v">${v}</span>`;
    grid.appendChild(div);
  }
  const elems = $('hsElements');
  elems.innerHTML = '';
  if (d.elements && d.elements.length) {
    const title = document.createElement('div');
    title.style.fontWeight = '700';
    title.textContent = '申报要素';
    elems.appendChild(title);
    for (const el of d.elements) {
      const div = document.createElement('div');
      div.textContent = el;
      elems.appendChild(div);
    }
  }
  $('hsDetailCard').hidden = false;
  $('hsCopyBtn').onclick = () => copyText(row.code, { type: 'hs', input: { code: row.code, name: row.name } });
  $('hsDetailOpenBtn').onclick = () => chrome.tabs.create({ url: row.url });
}

async function addHsToCommon() {
  const row = hsSelected;
  if (!row) {
    showStatus('请先在结果中选择一个编码');
    return;
  }
  await addCommonItem({
    type: 'hs',
    name: `${row.code} ${hsDetailData?.name || row.name}`.slice(0, 60),
    category: '海关编码',
    output: `${row.code} ${hsDetailData?.name || row.name}`,
    hsCode: row.code,
    hsName: hsDetailData?.name || row.name,
    hsUnit: hsDetailData?.['计量单位'] || row.unit,
    hsRebate: hsDetailData?.['出口退税税率'] || row.rebate,
    hsDetail: hsDetailData || null
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
}

/* ================= 常用表 ================= */

function renderCommonFilter() {
  const select = $('commonTypeFilter');
  select.innerHTML = '<option value="">全部类型</option>';
  for (const [key, label] of Object.entries(TYPE_LABELS)) {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = label;
    select.appendChild(opt);
  }
}

function esc(text) {
  return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function renderCommonList() {
  const items = await getCommonItems();
  const typeFilter = $('commonTypeFilter').value;
  const kw = $('commonSearch').value.trim().toLowerCase();
  const visible = items
    .filter((it) => {
      if (typeFilter && it.type !== typeFilter) return false;
      if (!kw) return true;
      return [it.name, it.category, (it.tags || []).join(' '), it.note, it.hsCode].join(' ').toLowerCase().includes(kw);
    })
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (a.sortOrder || 0) - (b.sortOrder || 0));

  $('commonCount').textContent = `${items.length} / ${isPro() ? '∞' : 10}`;
  $('commonEmpty').classList.toggle('hidden', visible.length > 0);
  const list = $('commonList');
  list.innerHTML = '';
  const head = document.createElement('div');
  head.className = 'common-head';
  head.innerHTML = '<span>类型</span><span>名称</span><span>结果</span><span>操作</span>';
  list.appendChild(head);
  for (const item of visible) {
    const row = document.createElement('div');
    row.className = 'common-item';
    const cellType = document.createElement('div');
    cellType.className = 'cell-type';
    const badge = document.createElement('span');
    badge.className = 'type-badge';
    badge.textContent = TYPE_LABELS[item.type] || item.type;
    cellType.appendChild(badge);
    const cellName = document.createElement('div');
    cellName.className = 'cell-name';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = `${item.pinned ? '★ ' : ''}${item.name || '未命名'}`;
    const tags = document.createElement('div');
    tags.className = 'tags';
    tags.textContent = (item.tags || []).join('、');
    cellName.append(name, tags);
    const cellResult = document.createElement('div');
    cellResult.className = 'cell-result';
    const resultText = item.output || commonMeta(item) || '';
    const out = document.createElement('span');
    out.className = 'common-output';
    out.textContent = resultText;
    out.title = '点击复制';
    const outCopy = document.createElement('button');
    outCopy.className = 'copy-output-btn';
    outCopy.textContent = '复制';
    outCopy.addEventListener('click', (e) => {
      e.stopPropagation();
      if (resultText) copyText(resultText, { type: item.type, input: item });
    });
    cellResult.append(out, outCopy);
    const cellActions = document.createElement('div');
    cellActions.className = 'cell-actions';
    const loadBtn = document.createElement('button');
    loadBtn.textContent = '载入';
    loadBtn.addEventListener('click', () => loadCommonItem(item));
    const pinBtn = document.createElement('button');
    pinBtn.textContent = item.pinned ? '已置顶' : '置顶';
    pinBtn.addEventListener('click', async () => {
      await upsertCommonItem({ ...item, pinned: !item.pinned });
      await renderCommonList();
    });
    const editBtn = document.createElement('button');
    editBtn.textContent = '编辑';
    editBtn.addEventListener('click', () => openCommonForm(item));
    const delBtn = document.createElement('button');
    delBtn.className = 'danger';
    delBtn.textContent = '删除';
    delBtn.addEventListener('click', async () => {
      await removeCommonItem(item.id);
      await renderCommonList();
    });
    cellActions.append(loadBtn, pinBtn, editBtn, delBtn);
    row.append(cellType, cellName, cellResult, cellActions);
    list.appendChild(row);
  }
}

function commonMeta(item) {
  if (item.type === 'result') return item.output || item.label || '';
  if (item.type === 'dimension') {
    const dims = [item.length, item.width, item.height].filter((v) => v != null && v !== '').join(' x ');
    return `${item.category || ''} · ${(item.mode || '').toUpperCase()} · ${dims}${item.unit || ''}${item.weightGram ? ` · ${item.weightGram}g` : ''}`;
  }
  if (item.type === 'weight') return `${item.wValue} ${item.wUnit}`;
  if (item.type === 'currency') return `${item.curAmount} ${item.curFrom} → ${item.curTo}`;
  if (item.type === 'pricing') return `成本 ¥${item.cost} · 利润 ${formatNumber((item.profit || 0) * 100, 0)}% · 佣金 ${formatNumber((item.commission || 0) * 100, 0)}%`;
  if (item.type === 'hs') return `${item.hsCode} · ${item.hsName || ''}${item.hsUnit ? ` · ${item.hsUnit}` : ''}${item.hsRebate ? ` · 退税率 ${item.hsRebate}` : ''}`;
  return item.note || '';
}

function loadCommonItem(item) {
  if (item.type === 'result') {
    if (item.output) {
      copyText(item.output, { type: 'result', input: item });
      showStatus(`已复制：${item.output.slice(0, 40)}`);
    } else {
      showStatus('该单值结果没有可复制的内容');
    }
    return;
  }
  if (item.type === 'dimension') {
    switchTab('dim');
    document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.mode === item.mode));
    document.querySelectorAll('#scenarioSeg .seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.scenario === (item.scenario || 'listing')));
    $('dimUnit').value = item.unit || 'cm';
    $('dimLength').value = item.length || '';
    $('dimWidth').value = item.width || '';
    $('dimHeight').value = item.height || '';
    if (item.weightGram) {
      $('dimWeight').value = fromGram(item.weightGram, 'g');
      $('dimWeightUnit').value = 'g';
    }
    renderDimMode();
    showStatus(`已载入：${item.name || '常用项'}`);
  } else if (item.type === 'weight') {
    switchTab('weight');
    $('wValue').value = item.wValue || '';
    $('wUnit').value = item.wUnit || 'g';
    renderWeight();
    showStatus('已载入重量');
  } else if (item.type === 'currency') {
    switchTab('currency');
    $('curAmount').value = item.curAmount || '';
    $('curFrom').value = item.curFrom || 'CNY';
    $('curTo').value = item.curTo || 'USD';
    renderCurrency();
    showStatus('已载入汇率');
  } else if (item.type === 'pricing') {
    switchTab('price');
    $('priceCost').value = item.cost || '';
    $('priceProfit').value = formatNumber((item.profit || 0) * 100, 0);
    $('priceCommission').value = formatNumber((item.commission || 0) * 100, 0);
    $('priceRate').value = item.rate || '';
    renderPrice();
    showStatus('已载入定价');
  } else if (item.type === 'hs') {
    switchTab('hs');
    hsSelected = { code: item.hsCode, name: item.hsName || '', unit: item.hsUnit || '', rebate: item.hsRebate || '', url: `https://www.hsbianma.com/Code/${item.hsCode}.html` };
    hsDetailData = item.hsDetail || null;
    renderHsDetail(hsSelected);
    showStatus('已载入海关编码');
  }
}

function openCommonForm(item) {
  commonEditingId = item ? item.id : null;
  const form = $('commonForm');
  form.classList.remove('hidden');
  form.innerHTML = commonFormHtml(item);
  $('saveCommonBtn').addEventListener('click', saveCommonForm);
  $('cancelCommonBtn').addEventListener('click', () => {
    form.classList.add('hidden');
    form.innerHTML = '';
    commonEditingId = null;
  });
}

function commonFormHtml(item) {
  item = item || {};
  const type = item.type || 'dimension';
  const typeOptions = Object.entries(TYPE_LABELS).map(([k, v]) => `<option value="${k}" ${type === k ? 'selected' : ''}>${v}</option>`).join('');
  let fields = '';
  if (type === 'dimension') {
    fields = `
      <label>模式<select id="f_mode">${['1d', '2d', '3d'].map((m) => `<option value="${m}" ${item.mode === m ? 'selected' : ''}>${m.toUpperCase()}</option>`).join('')}</select></label>
      <label>单位<select id="f_unit">${LENGTH_UNITS.map((u) => `<option value="${u}" ${item.unit === u ? 'selected' : ''}>${u}</option>`).join('')}</select></label>
      <label>长<input id="f_length" type="number" step="any" value="${item.length || ''}" /></label>
      <label>宽<input id="f_width" type="number" step="any" value="${item.width || ''}" /></label>
      <label>高<input id="f_height" type="number" step="any" value="${item.height || ''}" /></label>
      <label>重量（g）<input id="f_weight" type="number" step="any" value="${item.weightGram || ''}" /></label>`;
  } else if (type === 'weight') {
    fields = `
      <label>重量<input id="f_wValue" type="number" step="any" value="${item.wValue || ''}" /></label>
      <label>单位<select id="f_wUnit">${WEIGHT_UNITS.map((u) => `<option value="${u}" ${item.wUnit === u ? 'selected' : ''}>${u}</option>`).join('')}</select></label>`;
  } else if (type === 'currency') {
    fields = `
      <label>金额<input id="f_curAmount" type="number" step="any" value="${item.curAmount || ''}" /></label>
      <label>从<select id="f_curFrom">${CURRENCIES.map((c) => `<option value="${c}" ${item.curFrom === c ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
      <label>到<select id="f_curTo">${CURRENCIES.map((c) => `<option value="${c}" ${item.curTo === c ? 'selected' : ''}>${c}</option>`).join('')}</select></label>`;
  } else if (type === 'pricing') {
    fields = `
      <label>成本（¥）<input id="f_cost" type="number" step="any" value="${item.cost || ''}" /></label>
      <label>利润 %<input id="f_profit" type="number" step="any" value="${formatNumber((item.profit || 0) * 100, 0)}" /></label>
      <label>佣金 %<input id="f_commission" type="number" step="any" value="${formatNumber((item.commission || 0) * 100, 0)}" /></label>
      <label>汇率<input id="f_rate" type="number" step="any" value="${item.rate || ''}" /></label>`;
  } else if (type === 'result') {
    fields = `
      <label>行标签<input id="f_label" value="${esc(item.label || '')}" /></label>
      <label>结果文本<input id="f_output" value="${esc(item.output || '')}" /></label>`;
  } else if (type === 'hs') {
    fields = `
      <label>海关编码<input id="f_hsCode" value="${esc(item.hsCode || '')}" /></label>
      <label>品名<input id="f_hsName" value="${esc(item.hsName || '')}" /></label>
      <label>计量单位<input id="f_hsUnit" value="${esc(item.hsUnit || '')}" /></label>
      <label>退税率<input id="f_hsRebate" value="${esc(item.hsRebate || '')}" /></label>`;
  }
  return `
    <div class="grid-3">
      <label>类型<select id="f_type">${typeOptions}</select></label>
      <label>名称<input id="f_name" value="${esc(item.name || '')}" placeholder="显示名称" /></label>
      <label>分类<input id="f_category" value="${esc(item.category || '')}" placeholder="例如：3C" /></label>
      ${fields}
      <label>标签<input id="f_tags" value="${esc((item.tags || []).join(','))}" placeholder="逗号分隔" /></label>
      <label>备注<input id="f_note" value="${esc(item.note || '')}" /></label>
      <label class="checkbox-row"><input id="f_pinned" type="checkbox" ${item.pinned ? 'checked' : ''} /> 置顶</label>
    </div>
    <div class="actions">
      <button id="saveCommonBtn" class="primary-button">保存</button>
      <button id="cancelCommonBtn" class="secondary-button">取消</button>
    </div>
  `;
}

async function saveCommonForm() {
  const items = await getCommonItems();
  if (!commonEditingId && !isPro() && items.length >= 10) {
    showStatus('免费版最多 10 条，开通会员可无限');
    return;
  }
  const existing = items.find((it) => it.id === commonEditingId) || {};
  const type = $('f_type').value;
  const item = {
    ...existing,
    id: commonEditingId || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type,
    name: $('f_name').value.trim(),
    category: $('f_category').value.trim(),
    tags: $('f_tags').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean),
    note: $('f_note').value.trim(),
    pinned: $('f_pinned').checked,
    sortOrder: existing.sortOrder ?? items.length
  };
  if (type === 'dimension') {
    Object.assign(item, {
      mode: $('f_mode').value,
      unit: $('f_unit').value,
      length: Number($('f_length').value || 0),
      width: Number($('f_width').value || 0),
      height: Number($('f_height').value || 0),
      weightGram: Number($('f_weight').value || 0)
    });
  } else if (type === 'weight') {
    Object.assign(item, { wValue: Number($('f_wValue').value || 0), wUnit: $('f_wUnit').value });
  } else if (type === 'currency') {
    Object.assign(item, { curAmount: Number($('f_curAmount').value || 0), curFrom: $('f_curFrom').value, curTo: $('f_curTo').value });
  } else if (type === 'pricing') {
    Object.assign(item, {
      cost: Number($('f_cost').value || 0),
      profit: Number($('f_profit').value || 0) / 100,
      commission: Number($('f_commission').value || 0) / 100,
      rate: Number($('f_rate').value || 0)
    });
  } else if (type === 'result') {
    Object.assign(item, {
      label: $('f_label').value.trim(),
      output: $('f_output').value.trim()
    });
  } else if (type === 'hs') {
    Object.assign(item, {
      hsCode: $('f_hsCode').value.trim(),
      hsName: $('f_hsName').value.trim(),
      hsUnit: $('f_hsUnit').value.trim(),
      hsRebate: $('f_hsRebate').value.trim()
    });
  }
  await upsertCommonItem(item);
  $('commonForm').classList.add('hidden');
  $('commonForm').innerHTML = '';
  commonEditingId = null;
  await renderCommonList();
  showStatus('已保存');
}

function exportJson() {
  getCommonItems().then((items) => downloadBlob(JSON.stringify(items, null, 2), 'hunit-common-items.json', 'application/json'));
}

function exportCsv() {
  getCommonItems().then((items) => {
    const keys = ['type', 'name', 'category', 'tags', 'mode', 'unit', 'length', 'width', 'height', 'weightGram', 'wValue', 'wUnit', 'curAmount', 'curFrom', 'curTo', 'cost', 'profit', 'commission', 'rate', 'hsCode', 'hsName', 'hsUnit', 'hsRebate', 'note', 'pinned'];
    const rows = items.map((it) => keys.map((k) => {
      const v = k === 'tags' ? (it.tags || []).join('|') : it[k];
      return `"${String(v ?? '').replace(/"/g, '""')}"`;
    }).join(','));
    downloadBlob([keys.join(','), ...rows].join('\n'), 'hunit-common-items.csv', 'text/csv');
  });
}

function downloadBlob(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function importFile(file) {
  if (!isPro()) {
    showStatus('导入导出为会员功能');
    return;
  }
  try {
    const text = await file.text();
    let items;
    if (file.name.endsWith('.json')) {
      items = JSON.parse(text);
      if (!Array.isArray(items)) throw new Error('JSON 格式错误');
    } else {
      items = parseCsv(text);
    }
    const current = await getCommonItems();
    const next = [...current];
    for (const raw of items) {
      const item = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        type: TYPE_LABELS[raw.type] ? raw.type : 'dimension',
        name: String(raw.name || '未命名'),
        category: String(raw.category || ''),
        tags: Array.isArray(raw.tags) ? raw.tags : String(raw.tags || '').split(/[|,，]/).filter(Boolean),
        note: String(raw.note || ''),
        pinned: Boolean(raw.pinned),
        sortOrder: next.length,
        ...raw
      };
      next.push(item);
    }
    await chrome.storage.local.set({ hunit_common_items: next });
    await renderCommonList();
    showStatus(`导入 ${items.length} 条`);
  } catch (err) {
    showStatus(`导入失败：${err?.message || err}`);
  }
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  if (!lines.length) return [];
  const parseLine = (line) => {
    const out = [];
    let cur = '';
    let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQ && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQ = !inQ;
        }
      } else if (ch === ',' && !inQ) {
        out.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur);
    return out;
  };
  const headers = parseLine(lines[0]);
  return lines.slice(1).map((line) => {
    const vals = parseLine(line);
    const obj = {};
    headers.forEach((h, i) => {
      obj[h.trim()] = vals[i] != null ? vals[i].trim() : '';
    });
    return obj;
  });
}

/* ================= 设置 ================= */

async function fillSettings() {
  $('baseUrl').value = settings.baseUrl || '';
  $('appSlug').value = settings.appSlug || '';
  $('accessToken').value = settings.accessToken || '';
  $('theme').value = settings.theme || 'auto';
  $('dimensionMode').value = settings.dimensionMode || '1d';
  $('scenario').value = settings.scenario || 'listing';
  $('defaultUnit').value = settings.defaultUnit || 'cm';
  $('divisor').value = String(settings.divisor || 5000);
  $('precision').value = String(settings.precision || 2);
  $('defaultCurrency').value = settings.defaultCurrency || 'CNY';
  $('manualRatesEnabled').checked = Boolean(settings.manualRatesEnabled);
  renderManualRates();
}

function renderManualRates() {
  const grid = $('manualRatesGrid');
  grid.innerHTML = '';
  const rates = settings.manualRates || DEFAULT_RATES;
  for (const c of CURRENCIES) {
    const label = document.createElement('label');
    label.textContent = `USD → ${c}`;
    const input = document.createElement('input');
    input.type = 'number';
    input.step = 'any';
    input.id = `rate_${c}`;
    input.value = rates[c] != null ? rates[c] : DEFAULT_RATES[c];
    label.appendChild(input);
    grid.appendChild(label);
  }
}

async function collectSettings() {
  const manualRates = { ...DEFAULT_RATES };
  for (const c of CURRENCIES) {
    const v = Number($(`rate_${c}`)?.value);
    if (Number.isFinite(v) && v > 0) manualRates[c] = v;
  }
  return {
    ...settings,
    baseUrl: $('baseUrl').value.trim().replace(/\/$/, ''),
    appSlug: $('appSlug').value.trim(),
    appId: 0,
    accessToken: $('accessToken').value.trim(),
    theme: $('theme').value,
    dimensionMode: $('dimensionMode').value,
    scenario: $('scenario').value,
    defaultUnit: $('defaultUnit').value,
    divisor: Number($('divisor').value),
    precision: Number($('precision').value),
    defaultCurrency: $('defaultCurrency').value,
    manualRates,
    manualRatesEnabled: $('manualRatesEnabled').checked
  };
}

async function saveSettingsForm() {
  try {
    settings = await saveSettings(await collectSettings());
    applyTheme();
    $('connectionResult').textContent = '已保存。';
  } catch (err) {
    $('connectionResult').textContent = err?.message || '保存失败';
  }
}

async function testConnection() {
  try {
    settings = await saveSettings(await collectSettings());
    applyTheme();
    const resolved = await resolveAppId(settings);
    const info = await getEntitlement();
    entitlement = info;
    renderQuota();
    const active = isPro();
    const remaining = info.free_remaining_today ?? 0;
    $('connectionResult').textContent = `连接成功。App ID: ${resolved.appId || '未解析'}；${active ? '会员已开通' : `今日免费剩余 ${remaining} 次`}。`;
  } catch (err) {
    $('connectionResult').textContent = err?.message || '连接失败';
  }
}

/* ================= Tab / 窗口 ================= */

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
  $(`panel-${name}`).classList.add('active');
  $('upgradePanel').classList.add('hidden');
  if (name === 'common') renderCommonList();
  if (name === 'price') renderPrice();
  location.hash = name;
  settings.lastTab = name;
  saveSettings(settings).catch(() => {});
}

function openMaximized() {
  chrome.tabs.create({ url: chrome.runtime.getURL('app.html?window=1') });
}

/* ================= 事件 ================= */

document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

document.querySelectorAll('#modeSeg .seg-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderDimMode();
  });
});

document.querySelectorAll('#scenarioSeg .seg-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#scenarioSeg .seg-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderDimMode();
  });
});

for (const id of ['dimLength', 'dimWidth', 'dimHeight', 'dimWeight']) {
  $(id).addEventListener('input', () => {
    clearTimeout(dimTimer);
    dimTimer = setTimeout(renderDimension, 120);
  });
}
for (const id of ['dimUnit', 'dimDivisor', 'dimWeightUnit']) {
  $(id).addEventListener('change', renderDimension);
}

$('parseBtn').addEventListener('click', parsePaste);
$('pasteInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') parsePaste();
});
$('favBtn').addEventListener('click', async () => {
  const input = currentDimInputs();
  if (!input.length && !input.width && !input.height) {
    showStatus('请先输入尺寸');
    return;
  }
  const key = JSON.stringify({ mode: input.mode, unit: input.unit, length: input.length, width: input.width, height: input.height });
  const entry = {
    id: currentFavoriteId || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    inputKey: key,
    name: `${input.length || 0}${input.unit} ${input.mode.toUpperCase()}`,
    mode: input.mode,
    unit: input.unit,
    length: input.length,
    width: input.width,
    height: input.height
  };
  await toggleFavorite(entry);
  showStatus(currentFavoriteId ? '已取消收藏' : '已收藏');
  await updateFavoriteState(input);
});
$('addDimCommonBtn').addEventListener('click', addDimToCommon);

$('wValue').addEventListener('input', renderWeight);
$('wUnit').addEventListener('change', renderWeight);
$('addWeightCommonBtn').addEventListener('click', async () => {
  const value = Number($('wValue').value || 0);
  if (!value) {
    showStatus('请先输入重量');
    return;
  }
  await addCommonItem({
    type: 'weight',
    name: `${value} ${$('wUnit').value}`,
    category: '重量',
    output: convertWeight(value, $('wUnit').value, settings.precision).rows.map((r) => `${formatNumber(r.value, settings.precision)} ${r.label}`).join(' | '),
    wValue: value,
    wUnit: $('wUnit').value
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
});

$('curAmount').addEventListener('input', renderCurrency);
$('curFrom').addEventListener('change', renderCurrency);
$('curTo').addEventListener('change', renderCurrency);
$('addCurCommonBtn').addEventListener('click', async () => {
  const amount = Number($('curAmount').value || 0);
  if (!amount) {
    showStatus('请先输入金额');
    return;
  }
  const value = ratesInfo ? convertCurrency(amount, $('curFrom').value, $('curTo').value, ratesInfo.rates) : null;
  await addCommonItem({
    type: 'currency',
    name: `${amount} ${$('curFrom').value} → ${$('curTo').value}`,
    category: '汇率',
    output: value === null ? `${amount} ${$('curFrom').value} → ${$('curTo').value}` : `${formatNumber(value, 2)} ${$('curTo').value}`,
    curAmount: amount,
    curFrom: $('curFrom').value,
    curTo: $('curTo').value
  });
  await renderCommonList();
  showStatus('已加入常用表 ✓');
});

for (const id of ['priceCost', 'priceProfit', 'priceCommission', 'priceRate']) {
  $(id).addEventListener('input', renderPrice);
}
$('addPriceCommonBtn').addEventListener('click', addPriceToCommon);

$('hsSearchBtn').addEventListener('click', runHsSearch);
$('hsSearch').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') runHsSearch();
});
$('addHsCommonBtn').addEventListener('click', addHsToCommon);

$('commonTypeFilter').addEventListener('change', renderCommonList);
$('commonSearch').addEventListener('input', renderCommonList);
$('addCommonBtn').addEventListener('click', () => openCommonForm(null));
$('exportJsonBtn').addEventListener('click', exportJson);
$('exportCsvBtn').addEventListener('click', exportCsv);
$('importFile').addEventListener('change', (e) => {
  if (e.target.files[0]) importFile(e.target.files[0]);
  e.target.value = '';
});

$('saveSettings').addEventListener('click', saveSettingsForm);
$('testConnection').addEventListener('click', testConnection);
$('clearHistoryBtn').addEventListener('click', async () => {
  await clearHistory();
  showStatus('历史已清空');
});
$('clearFavoritesBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ hunit_favorites: [] });
  showStatus('收藏已清空');
});
$('clearCommonBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ hunit_common_items: [] });
  await renderCommonList();
  showStatus('常用表已清空');
});

$('subscribeButton').addEventListener('click', async () => {
  const button = $('subscribeButton');
  const message = $('upgradeMessage');
  if (!settings.accessToken) {
    message.textContent = '请先在设置中连接 AjkAPI';
    switchTab('settings');
    return;
  }
  button.disabled = true;
  button.textContent = '正在开通…';
  try {
    await subscribeMonthly();
    await refreshEntitlement();
    showStatus('会员开通成功');
  } catch (err) {
    message.textContent = err?.message || '开通失败，请检查 AjkAPI 连接和余额';
    showStatus('开通失败');
  } finally {
    button.disabled = false;
    button.textContent = '2 元/月，从余额开通';
  }
});
$('unsubscribeButton').addEventListener('click', async () => {
  const button = $('unsubscribeButton');
  const message = $('upgradeMessage');
  if (!confirm('退订后当前包月仍可使用至到期日，到期后自动恢复免费版。确定退订吗？')) return;
  button.disabled = true;
  button.textContent = '正在退订…';
  try {
    await unsubscribeMonthly();
    await refreshEntitlement();
    renderMembership();
    showStatus('已申请退订，会员服务至到期日');
  } catch (err) {
    message.textContent = err?.message || '退订失败';
    showStatus('退订失败');
  } finally {
    button.disabled = false;
    button.textContent = '退订包月（下月生效）';
  }
});
$('openSettingsBtn').addEventListener('click', () => switchTab('settings'));

$('membershipBtn').addEventListener('click', () => {
  $('upgradeMessage').textContent = '';
  renderMembership();
  $('upgradePanel').classList.toggle('hidden');
});

$('maximizeBtn').addEventListener('click', openMaximized);
$('maximizeFooterBtn').addEventListener('click', openMaximized);

window.addEventListener('hashchange', () => {
  const name = location.hash.replace('#', '');
  if (name && document.querySelector(`.tab-btn[data-tab="${name}"]`)) {
    switchTab(name);
  }
});

/* ================= 初始化 ================= */

document.addEventListener('DOMContentLoaded', async () => {
  window.__HUNIT_APP_INIT__ = true;
  if (IS_MAXIMIZED) {
    document.body.classList.add('maximized');
    $('maximizeBtn').classList.add('hidden');
    $('maximizeFooterBtn').classList.add('hidden');
  }

  settings = await getSettings();
  applyTheme();
  renderCurrencySelects();
  renderWQuick();
  renderDimMode();
  renderCommonFilter();
  renderCommonList();
  fillSettings();

  ratesInfo = await getRates();
  renderCurrency();
  $('priceRate').value = '7.2';
  if (!$('priceProfit').value) $('priceProfit').value = '30';
  if (!$('priceCommission').value) $('priceCommission').value = '15';
  renderPrice();

  await refreshEntitlement();

  const initialTab = location.hash.replace('#', '') || settings.lastTab || 'dim';
  if (document.querySelector(`.tab-btn[data-tab="${initialTab}"]`)) {
    switchTab(initialTab);
  } else {
    switchTab('dim');
  }
});
