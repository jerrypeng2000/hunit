import puppeteer from 'puppeteer-core';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const TOKEN = 'XDyxhNnw9PjpqWzrJKsKHRemDwGLQz3AfBqOLIQTJPaEIrXC';

const browser = await puppeteer.launch({
  executablePath: chromePath,
  headless: false,
  ignoreDefaultArgs: ['--disable-extensions'],
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-gpu',
    '--window-position=-32000,-32000',
    `--disable-extensions-except=${dist}`,
    `--load-extension=${dist}`
  ]
});

await new Promise((r) => setTimeout(r, 2500));
const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
const extensionId = new URL(worker.url()).host;
const page = await browser.newPage();
page.on('console', (msg) => {
  if (msg.type() === 'error' || msg.type() === 'warning') console.log(`[${msg.type()}]`, msg.text());
});
page.on('pageerror', (err) => console.log('[pageerror]', err.message));
await page.goto(`chrome-extension://${extensionId}/popup.html`);
await new Promise((r) => setTimeout(r, 12000));
await page.evaluate((token) => chrome.storage.sync.set({
  settings: {
    baseUrl: 'https://ajkapi.9zos.com', appSlug: 'hunit', appId: 19, accessToken: token,
    theme: 'auto', dimensionMode: '1d', scenario: 'listing', defaultUnit: 'cm', defaultCurrency: 'CNY',
    precision: 2, divisor: 5000, manualRatesEnabled: false,
    manualRates: { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 }
  }
}), TOKEN);
await page.reload();
for (let i = 0; i < 6; i++) {
  await new Promise((r) => setTimeout(r, 5000));
  const status = await page.$eval('#statusText', (el) => el.textContent.trim()).catch(() => 'n/a');
  const quota = await page.$eval('#quotaValue', (el) => el.textContent.trim()).catch(() => 'n/a');
  const membership = await page.$eval('#membershipStatus', (el) => el.textContent.trim()).catch(() => 'n/a');
  console.log(`t+${(i + 1) * 5}s status="${status}" quota=${quota} membership="${membership}"`);
}
await browser.close();
