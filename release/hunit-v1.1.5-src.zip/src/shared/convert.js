export const LENGTH_UNITS = ['mm', 'cm', 'm', 'in', 'ft', 'yd'];
export const WEIGHT_UNITS = ['g', 'kg', 'lb', 'oz'];
export const AREA_UNITS = ['mm²', 'cm²', 'm²', 'in²', 'ft²', 'yd²'];
export const VOLUME_UNITS = ['cm³', 'm³', 'in³', 'ft³', 'L'];

const LENGTH_TO_CM = { mm: 0.1, cm: 1, m: 100, in: 2.54, ft: 30.48, yd: 91.44 };
const WEIGHT_TO_G = { g: 1, kg: 1000, lb: 453.59237, oz: 28.349523125 };

export function isMetricUnit(unit) {
  return ['mm', 'cm', 'm'].includes(unit);
}

export function defaultTargetUnit(unit) {
  return isMetricUnit(unit) ? 'in' : 'cm';
}

export function toCm(value, unit) {
  return Number(value) * LENGTH_TO_CM[unit];
}

export function fromCm(cm, unit) {
  return Number(cm) / LENGTH_TO_CM[unit];
}

export function toGram(value, unit) {
  return Number(value) * WEIGHT_TO_G[unit];
}

export function fromGram(g, unit) {
  return Number(g) / WEIGHT_TO_G[unit];
}

export function formatNumber(value, precision = 2) {
  if (!Number.isFinite(Number(value))) return '—';
  const num = Number(value);
  const fixed = num.toFixed(precision);
  return Number(fixed).toLocaleString('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision
  });
}

export function formatFlex(value, precision = 2) {
  if (!Number.isFinite(Number(value))) return '—';
  const num = Number(value);
  return Number(num.toFixed(precision)).toLocaleString('en-US', {
    maximumFractionDigits: precision
  });
}

export function areaUnit(unit) {
  if (unit === 'm') return 'm²';
  if (unit === 'ft') return 'ft²';
  if (unit === 'yd') return 'yd²';
  if (unit === 'mm') return 'mm²';
  if (unit === 'in') return 'in²';
  return 'cm²';
}

export function volumeUnit(unit) {
  if (unit === 'm') return 'm³';
  if (unit === 'ft') return 'ft³';
  if (unit === 'in') return 'in³';
  if (unit === 'mm') return 'cm³';
  return 'cm³';
}

export function listingUnitName(unit) {
  if (unit === 'in') return 'inches';
  if (unit === 'ft') return 'feet';
  return unit;
}

export function pluralUnit(unit) {
  if (unit === 'in') return 'in';
  if (unit === 'ft') return 'ft';
  if (unit === 'yd') return 'yd';
  return unit;
}

export function volumetricKg(cm3, divisor) {
  return Number(cm3) / Number(divisor);
}

export function volumetricLb(in3, divisor) {
  return Number(in3) / Number(divisor);
}

export function convertWeight(value, unit, precision = 2) {
  const grams = toGram(value, unit);
  const rows = WEIGHT_UNITS.map((u) => ({
    label: u,
    value: fromGram(grams, u),
    unit: u
  }));
  return { grams, rows };
}

export function convertDimensions(opts) {
  const {
    mode = '1d',
    unit = 'cm',
    targetUnit = null,
    length = 0,
    width = 0,
    height = 0,
    divisor = 5000,
    precision = 2,
    scenario = 'listing',
    weightGram = 0
  } = opts;

  const target = targetUnit || defaultTargetUnit(unit);
  const lcm = toCm(length, unit);
  const wcm = toCm(width, unit);
  const hcm = toCm(height, unit);
  const areaCm2 = lcm * wcm;
  const volCm3 = lcm * wcm * hcm;

  const fmt = (v) => formatNumber(v, precision);
  const rows = [];

  if (mode === '1d') {
    for (const u of LENGTH_UNITS) {
      rows.push({
        label: u,
        main: fromCm(lcm, u),
        mainUnit: u,
        alt: fromCm(lcm, target),
        altUnit: target,
        kind: 'length'
      });
    }
  } else if (mode === '2d') {
    rows.push(
      { label: '长', main: Number(length), mainUnit: unit, alt: fromCm(lcm, target), altUnit: target, kind: 'length' },
      { label: '宽', main: Number(width), mainUnit: unit, alt: fromCm(wcm, target), altUnit: target, kind: 'length' },
      {
        label: '面积',
        main: areaCm2 / (LENGTH_TO_CM[unit] * LENGTH_TO_CM[unit]),
        mainUnit: areaUnit(unit),
        alt: areaCm2 / (LENGTH_TO_CM[target] * LENGTH_TO_CM[target]),
        altUnit: areaUnit(target),
        kind: 'area'
      }
    );
  } else {
    rows.push(
      { label: '长', main: Number(length), mainUnit: unit, alt: fromCm(lcm, target), altUnit: target, kind: 'length' },
      { label: '宽', main: Number(width), mainUnit: unit, alt: fromCm(wcm, target), altUnit: target, kind: 'length' },
      { label: '高', main: Number(height), mainUnit: unit, alt: fromCm(hcm, target), altUnit: target, kind: 'length' },
      {
        label: '体积',
        main: volCm3 / Math.pow(LENGTH_TO_CM[unit], 3),
        mainUnit: volumeUnit(unit),
        alt: volCm3 / Math.pow(LENGTH_TO_CM[target], 3),
        altUnit: volumeUnit(target),
        kind: 'volume'
      }
    );

    const isMetricDivisor = Number(divisor) === 5000 || Number(divisor) === 6000;
    const vwMain = isMetricDivisor
      ? volumetricKg(volCm3, divisor)
      : volumetricLb(volCm3 / Math.pow(LENGTH_TO_CM.in, 3), divisor);
    const vwKg = volumetricKg(volCm3, 5000);
    const vwLb = volumetricLb(volCm3 / Math.pow(LENGTH_TO_CM.in, 3), 139);
    rows.push({
      label: '体积重',
      main: vwMain,
      mainUnit: isMetricDivisor ? 'kg' : 'lb',
      alt: isMetricDivisor ? vwLb : vwKg,
      altUnit: isMetricDivisor ? 'lb' : 'kg',
      kind: 'volumetric'
    });

    if (weightGram > 0) {
      const chargeable = Math.max(weightGram / 1000, vwKg);
      rows.push({
        label: '计费重',
        main: chargeable,
        mainUnit: 'kg',
        alt: fromGram(chargeable * 1000, 'lb'),
        altUnit: 'lb',
        kind: 'chargeable'
      });
    }
  }

  const cardLines = rows.map((r) => {
    const altText = r.altUnit === r.mainUnit ? '' : ` / ${fmt(r.alt)} ${r.altUnit}`;
    return `${r.label}  ${fmt(r.main)} ${r.mainUnit}${altText}`;
  });

  let listing = '';
  if (mode === '2d') {
    listing = `${fmt(Number(length))} x ${fmt(Number(width))} ${listingUnitName(unit)}`;
  } else if (mode === '3d') {
    listing = `${fmt(Number(length))} x ${fmt(Number(width))} x ${fmt(Number(height))} ${listingUnitName(unit)}`;
  }

  return {
    mode,
    unit,
    target,
    rows,
    cardText: cardLines.join('\n'),
    listing,
    lcm,
    wcm,
    hcm,
    areaCm2,
    volCm3
  };
}
