const UNIT_RE = /(mm|cm|m|in|ft|yd)["']?\s*$/i;
const DIM_SPLIT_RE = /[x×*]/i;
const WEIGHT_RE = /^(\d+(?:\.\d+)?)\s*(g|kg|lb|oz)\s*$/i;
const LENGTH_RE = /^(\d+(?:\.\d+)?)\s*(mm|cm|m|in|ft|yd)?\s*("|')?\s*$/i;
const CURRENCY_RE = /([¥$€£])\s*(\d+(?:\.\d+)?)/;

const CURRENCY_BY_SYMBOL = { '¥': 'CNY', '$': 'USD', '€': 'EUR', '£': 'GBP' };

export function parseDimensionText(raw) {
  const text = String(raw || '').trim();
  if (!text) return null;

  const unitMatch = text.match(UNIT_RE);
  let unit = unitMatch ? unitMatch[1].toLowerCase() : null;
  let body = unitMatch ? text.slice(0, unitMatch.index).trim() : text;

  const parts = body.split(DIM_SPLIT_RE).map((s) => s.trim()).filter(Boolean);
  if (parts.length < 1 || parts.length > 3) return null;

  const numbers = [];
  for (const part of parts) {
    const m = part.match(LENGTH_RE);
    if (!m) return null;
    const value = Number(m[1]);
    if (!Number.isFinite(value)) return null;
    if (m[3] === '"' || m[3] === "'") {
      unit = unit || (m[3] === '"' ? 'in' : 'ft');
    }
    if (m[2]) unit = unit || m[2].toLowerCase();
    numbers.push(value);
  }

  unit = unit || 'cm';
  if (!['mm', 'cm', 'm', 'in', 'ft', 'yd'].includes(unit)) return null;

  if (parts.length === 1) {
    return { mode: '1d', length: numbers[0], unit };
  }
  if (parts.length === 2) {
    return { mode: '2d', length: numbers[0], width: numbers[1], unit };
  }
  return { mode: '3d', length: numbers[0], width: numbers[1], height: numbers[2], unit };
}

export function parseWeightText(raw) {
  const text = String(raw || '').trim();
  if (!text) return null;
  const m = text.match(WEIGHT_RE);
  if (!m) return null;
  const unit = m[2].toLowerCase();
  if (!['g', 'kg', 'lb', 'oz'].includes(unit)) return null;
  return { value: Number(m[1]), unit };
}

export function parseCurrencyText(raw) {
  const text = String(raw || '').trim();
  if (!text) return null;
  const m = text.match(CURRENCY_RE);
  if (!m) return null;
  return { amount: Number(m[2]), currency: CURRENCY_BY_SYMBOL[m[1]] };
}

export function containsConvertiblePattern(text) {
  const value = String(text || '').trim();
  if (!value || value.length > 80) return false;
  return (
    parseDimensionText(value) !== null ||
    parseWeightText(value) !== null ||
    parseCurrencyText(value) !== null
  );
}
