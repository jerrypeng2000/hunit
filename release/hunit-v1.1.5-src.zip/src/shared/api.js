import { getSettings, saveSettings, todayKey, getLocalQuota, incrementLocalUsageCount } from './storage.js';

export const FREE_DAILY_QUOTA = 10;

async function fetchWithTimeout(url, options = {}, timeout = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function headers(settings) {
  return {
    'Content-Type': 'application/json',
    'Authorization': settings.accessToken || ''
  };
}

export async function resolveAppId(settings) {
  if (settings.appId > 0) return settings;
  if (!settings.appSlug) return settings;
  let lastError = '未知错误';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const resp = await fetchWithTimeout(`${settings.baseUrl}/api/marketplace/apps/${encodeURIComponent(settings.appSlug)}`);
      if (!resp.ok) {
        lastError = `HTTP ${resp.status}`;
        if (attempt < 3) {
          await new Promise((r) => setTimeout(r, 800 * attempt));
          continue;
        }
        break;
      }
      const json = await resp.json();
      const id = json?.data?.app?.id;
      if (id) {
        settings.appId = id;
        await saveSettings(settings);
        return settings;
      }
      lastError = '响应中未找到应用 ID';
    } catch (err) {
      lastError = err?.message || String(err);
      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, 800 * attempt));
        continue;
      }
    }
  }
  throw new Error(`应用解析失败（${lastError}），请检查应用标识（slug）或稍后重试`);
}

export async function getEntitlement() {
  let settings = await getSettings();
  if (!settings.accessToken) {
    const local = await getLocalQuota();
    const used = local.date === todayKey() ? local.used : 0;
    return {
      free_enabled: true,
      free_daily_quota: FREE_DAILY_QUOTA,
      free_used_today: used,
      free_remaining_today: Math.max(0, FREE_DAILY_QUOTA - used),
      plugin_monthly_active: false,
      monthly_price_quota: 0,
      monthly_duration_days: 30,
      requires_upgrade: false,
      local: true
    };
  }

  settings = await resolveAppId(settings);
  if (!settings.appId) {
    throw new Error('无法解析应用 ID，请检查应用标识（slug）或稍后重试');
  }

  const resp = await fetchWithTimeout(`${settings.baseUrl}/api/billing/app-quota?app_id=${settings.appId}`, {
    headers: headers(settings)
  });
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`查询额度失败（${resp.status}）：${text}`);
  }
  const json = await resp.json();
  const data = json?.data || {};
  const detail = data.detail || data;
  return { ...detail, user_id: data.user_id || detail.user_id || 0, local: false };
}

export async function consumeUsage(count = 1) {
  let settings = await getSettings();
  if (!settings.accessToken) {
    const quota = await getLocalQuota();
    if (quota.date !== todayKey()) {
      quota.date = todayKey();
      quota.used = 0;
    }
    if (count > 1 || quota.used >= FREE_DAILY_QUOTA) {
      return {
        success: false,
        requires_upgrade: true,
        message: count > 1 ? '批量换算需要付费会员' : '今日免费额度已用完'
      };
    }
    await incrementLocalUsageCount();
    return {
      success: true,
      source: 'free',
      free_used_today: quota.used + 1,
      free_remaining_today: Math.max(0, FREE_DAILY_QUOTA - quota.used - 1),
      requires_upgrade: false
    };
  }

  settings = await resolveAppId(settings);
  const requestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  const resp = await fetchWithTimeout(`${settings.baseUrl}/api/billing/consume`, {
    method: 'POST',
    headers: headers(settings),
    body: JSON.stringify({
      app_id: settings.appId,
      call_count: count,
      token_count: 0,
      request_id: requestId
    })
  });

  const json = await resp.json();
  if (!resp.ok && resp.status !== 402) {
    throw new Error(`计费请求失败（${resp.status}）：${json?.message || resp.statusText}`);
  }
  return {
    success: json?.success,
    requires_upgrade: json?.data?.requires_upgrade || json?.data?.RequiresUpgrade || false,
    source: json?.data?.source,
    message: json?.message || json?.data?.message,
    free_used_today: json?.data?.free_used_today,
    free_remaining_today: json?.data?.free_remaining_today,
    plugin_monthly_active: json?.data?.plugin_monthly_active
  };
}

export async function subscribeMonthly() {
  let settings = await getSettings();
  if (!settings.accessToken) {
    throw new Error('请先在设置中连接 AjkAPI');
  }
  settings = await resolveAppId(settings);
  const resp = await fetchWithTimeout(`${settings.baseUrl}/api/billing/app-subscribe`, {
    method: 'POST',
    headers: headers(settings),
    body: JSON.stringify({ app_id: settings.appId })
  });
  const json = await resp.json();
  if (!resp.ok) {
    throw new Error(json?.message || `开通失败（${resp.status}）`);
  }
  return json?.data;
}

export async function unsubscribeMonthly() {
  let settings = await getSettings();
  if (!settings.accessToken) {
    throw new Error('请先在设置中连接 AjkAPI');
  }
  settings = await resolveAppId(settings);
  const resp = await fetchWithTimeout(`${settings.baseUrl}/api/billing/app-unsubscribe`, {
    method: 'POST',
    headers: headers(settings),
    body: JSON.stringify({ app_id: settings.appId })
  });
  const json = await resp.json();
  if (!resp.ok) {
    throw new Error(json?.message || `退订失败（${resp.status}）`);
  }
  return json?.data;
}

export async function testConnection() {
  return getEntitlement();
}
