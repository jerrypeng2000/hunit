const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';

function stripTags(s) {
  return String(s || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parseSearchHtml(html) {
  const rows = [];
  const chunkRe = /<tr class="result-grid">([\s\S]*?)<\/tr>/g;
  let m;
  while ((m = chunkRe.exec(html))) {
    const block = m[1];
    const codeMatch = block.match(/<a href="\/Code\/(\d+)\.html">(\d+)<\/a>/);
    if (!codeMatch) continue;
    const tds = Array.from(block.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)).map((x) => stripTags(x[1]));
    rows.push({
      code: codeMatch[2],
      name: tds[1] || '',
      unit: tds[2] || '',
      rebate: tds[3] || '',
      regulatory: tds[4] || '',
      inspection: tds[5] || '',
      url: `https://www.hsbianma.com/Code/${codeMatch[2]}.html`
    });
  }
  return rows;
}

export function parseDetailHtml(html) {
  const out = {};
  const pairRe = /<td class="td-label">([\s\S]*?)<\/td>[\s\S]*?<td class="td-txt"[^>]*>([\s\S]*?)<\/td>/g;
  let m;
  while ((m = pairRe.exec(html))) {
    const label = stripTags(m[1]);
    if (!label || /^\d+$/.test(label)) continue;
    out[label] = stripTags(m[2]);
  }

  const titleMatch = html.match(/<title>(\d+)的HS编码_([^_]+)_HS编码查询<\/title>/);
  if (titleMatch) {
    out.code = out.code || titleMatch[1];
    out.name = out.name || titleMatch[2];
  }

  const elements = [];
  const es = html.indexOf('申报要素');
  if (es >= 0) {
    const end = html.indexOf('<h3', es + 10);
    const section = end >= 0 ? html.slice(es, end) : html.slice(es);
    for (const tm of section.matchAll(/<td class="td-txt"[^>]*>([\s\S]*?)<\/td>/g)) {
      const text = stripTags(tm[1]).replace(/\s*\[\s*\?\s*\]\s*$/, '').trim();
      if (text) elements.push(text);
    }
  }
  out.elements = elements;
  return out;
}

export async function searchHs(keyword) {
  const q = String(keyword || '').trim();
  if (!q) throw new Error('请输入查询关键词');
  const resp = await fetch(`https://www.hsbianma.com/search?keywords=${encodeURIComponent(q)}`, {
    headers: { 'User-Agent': UA, 'Referer': 'https://www.hsbianma.com/' }
  });
  if (!resp.ok) throw new Error(`查询失败（HTTP ${resp.status}）`);
  const html = await resp.text();
  return parseSearchHtml(html);
}

export async function hsDetail(code) {
  const resp = await fetch(`https://www.hsbianma.com/Code/${encodeURIComponent(code)}.html`, {
    headers: { 'User-Agent': UA, 'Referer': 'https://www.hsbianma.com/search' }
  });
  if (!resp.ok) throw new Error(`详情获取失败（HTTP ${resp.status}）`);
  const html = await resp.text();
  return parseDetailHtml(html);
}
