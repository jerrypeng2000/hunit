import { consumeUsage } from './shared/api.js';
import { getSettings } from './shared/storage.js';
import { convertDimensions, convertWeight } from './shared/convert.js';
import { parseDimensionText, parseWeightText, parseCurrencyText } from './shared/parser.js';
import { getRates, convertCurrency } from './shared/currency.js';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'hunit-convert-selection',
    title: '用换算通 HUnit 换算选中内容',
    contexts: ['selection']
  });
  chrome.alarms.create('hunit-refresh-rates', { periodInMinutes: 10 });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'hunit-convert-selection' || !info.selectionText) return;
  const result = await convertText(info.selectionText);
  if (!result.success) {
    notify('换算失败', result.message || '无法识别选中内容');
    return;
  }
  notify('换算结果', result.text);
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'hunit-refresh-rates') {
    getRates().catch(() => {});
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-hunit') return;
  try {
    if (chrome.action && typeof chrome.action.openPopup === 'function') {
      await chrome.action.openPopup();
      return;
    }
  } catch (err) {
    console.warn('openPopup failed', err);
  }
  chrome.runtime.openOptionsPage();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === 'HUNIT_CONVERT_TEXT') {
        const result = await convertText(message.text);
        sendResponse(result);
        return;
      }
      sendResponse({ success: false, message: '未知消息类型' });
    } catch (err) {
      sendResponse({ success: false, message: err?.message || String(err) });
    }
  })();
  return true;
});

async function convertText(raw) {
  const text = String(raw || '').trim();
  if (!text) return { success: false, message: '请先选中要换算的内容' };

  const dim = parseDimensionText(text);
  const weight = !dim ? parseWeightText(text) : null;
  const currency = !dim && !weight ? parseCurrencyText(text) : null;

  if (!dim && !weight && !currency) {
    return { success: false, message: '无法识别：支持 12x6x1、30*15*2cm、3.3ft、12"、500g、2kg、$20 等格式' };
  }

  const settings = await getSettings();
  let lines = [];
  let type = 'dimension';
  let input = {};

  if (dim) {
    const result = convertDimensions({
      mode: dim.mode,
      unit: dim.unit,
      length: dim.length,
      width: dim.width || 0,
      height: dim.height || 0,
      divisor: settings.divisor,
      precision: settings.precision,
      scenario: settings.scenario
    });
    lines = result.cardText.split('\n');
    input = dim;
  } else if (weight) {
    const result = convertWeight(weight.value, weight.unit, settings.precision);
    lines = result.rows.map((r) => `${r.label}  ${Number(r.value.toFixed(settings.precision)).toLocaleString('en-US', { maximumFractionDigits: settings.precision })}`);
    type = 'weight';
    input = weight;
  } else if (currency) {
    const ratesInfo = await getRates();
    const target = settings.defaultCurrency === currency.currency ? 'USD' : settings.defaultCurrency;
    const value = convertCurrency(currency.amount, currency.currency, target, ratesInfo.rates);
    if (value === null) return { success: false, message: '汇率数据不可用，请稍后重试' };
    lines = [`${currency.amount} ${currency.currency} = ${value.toFixed(2)} ${target}`];
    type = 'currency';
    input = { ...currency, target };
  }

  const consumption = await consumeUsage(1);
  if (!consumption.success) {
    return {
      success: false,
      requires_upgrade: consumption.requires_upgrade,
      message: consumption.message || '额度不足'
    };
  }

  return {
    success: true,
    type,
    text: lines.join('\n'),
    lines,
    input
  };
}

function notify(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message: String(message).slice(0, 500)
    });
  } catch (err) {
    console.warn('notification failed', err);
  }
}
