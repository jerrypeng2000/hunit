import { containsConvertiblePattern } from './shared/parser.js';

if (!document.documentElement?.dataset?.hunitInjected) {
  document.documentElement.dataset.hunitInjected = '1';

  let chip = null;
  let tooltip = null;

  function ensureChip() {
    if (chip) return;
    chip = document.createElement('div');
    chip.id = 'hunit-select-chip';
    chip.textContent = '换算';
    chip.addEventListener('mousedown', (e) => e.preventDefault());
    chip.addEventListener('click', async () => {
      const selection = window.getSelection();
      const text = selection ? selection.toString().trim() : '';
      if (!text) return;
      chip.hidden = true;
      showTooltip('换算中…');
      try {
        const response = await chrome.runtime.sendMessage({ type: 'HUNIT_CONVERT_TEXT', text });
        if (!response?.success) {
          showTooltip(response?.message || '无法换算');
          return;
        }
        showTooltip(response.lines.join('\n'), true);
      } catch (err) {
        showTooltip(err?.message || '请求失败');
      }
    });
    document.documentElement.appendChild(chip);
  }

  function positionChip(rect) {
    if (!chip) return;
    const top = rect.top - chip.offsetHeight - 6;
    const left = Math.max(4, Math.min(rect.left, window.innerWidth - chip.offsetWidth - 8));
    chip.style.top = `${top < 4 ? rect.bottom + 6 : top}px`;
    chip.style.left = `${left}px`;
  }

  function showTooltip(text, allowCopy = false) {
    if (!tooltip) {
      tooltip = document.createElement('div');
      tooltip.id = 'hunit-tooltip';
      document.documentElement.appendChild(tooltip);
    }
    tooltip.innerHTML = '';
    const pre = document.createElement('div');
    pre.className = 'hunit-tooltip-text';
    pre.textContent = text;
    tooltip.appendChild(pre);
    if (allowCopy) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = '复制';
      btn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(text);
          btn.textContent = '已复制';
        } catch (err) {
          btn.textContent = '复制失败';
        }
      });
      tooltip.appendChild(btn);
    }
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'hunit-tooltip-close';
    close.textContent = '×';
    close.addEventListener('click', hideTooltip);
    tooltip.appendChild(close);
    tooltip.hidden = false;
  }

  function hideTooltip() {
    if (tooltip) tooltip.hidden = true;
    if (chip) chip.hidden = true;
  }

  document.addEventListener('selectionchange', () => {
    const selection = window.getSelection();
    const text = selection ? selection.toString().trim() : '';
    if (text && containsConvertiblePattern(text) && selection.rangeCount > 0) {
      ensureChip();
      const rect = selection.getRangeAt(0).getBoundingClientRect();
      if (rect.width > 0 || rect.height > 0) {
        chip.hidden = false;
        positionChip(rect);
      }
    } else {
      hideTooltip();
      if (chip) chip.hidden = true;
    }
  });

  document.addEventListener('mousedown', (e) => {
    if (chip && !chip.contains(e.target) && (!tooltip || !tooltip.contains(e.target))) {
      hideTooltip();
    }
  });
}
