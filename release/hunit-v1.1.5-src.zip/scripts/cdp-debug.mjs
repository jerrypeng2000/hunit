import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { tmpdir } from 'node:os';

const root = resolve(import.meta.dirname, '..');
const CHROME = resolve(root, '..', '.tools', 'chrome-for-testing', 'chrome', 'win64-152.0.7977.54', 'chrome-win64', 'chrome.exe');
const PORT = 9340 + Math.floor(Math.random() * 40);
const CDP = `http://127.0.0.1:${PORT}`;
const extDir = resolve(tmpdir(), 'hunit-cdp-test', 'extension');
const profileDir = resolve(tmpdir(), `hunit-cdp-debug-${Date.now()}`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const chrome = spawn(CHROME, [
  `--remote-debugging-port=${PORT}`,
  `--user-data-dir=${profileDir}`,
  `--disable-extensions-except=${extDir}`,
  `--load-extension=${extDir}`,
  '--enable-unsafe-extension-debugging',
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-gpu',
  '--window-position=-32000,-32000',
  'about:blank'
], { stdio: 'ignore' });

chrome.on('exit', (code, signal) => console.log('chrome exited', code, signal));

for (let i = 0; i < 60; i++) {
  try {
    const v = await (await fetch(`${CDP}/json/version`)).json();
    console.log('chrome version:', v.Browser);
    break;
  } catch (_) {
    await sleep(500);
  }
}
await sleep(5000);
const list = await (await fetch(`${CDP}/json/list`)).json();
console.log('targets:');
for (const t of list) console.log(`  ${t.type} ${t.url}`);

const pageTarget = await (await fetch(`${CDP}/json/new?${encodeURIComponent('chrome://extensions-internals/')}`, { method: 'PUT' })).json();
const ws = new WebSocket(pageTarget.webSocketDebuggerUrl);
await new Promise((r) => { ws.onopen = r; });
let seq = 0;
const pending = new Map();
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    pending.get(msg.id)(msg.result);
    pending.delete(msg.id);
  }
};
function send(method, params = {}) {
  return new Promise((resolve) => {
    const id = ++seq;
    pending.set(id, resolve);
    ws.send(JSON.stringify({ id, method, params }));
  });
}
await send('Runtime.enable');
await sleep(6000);
const res = await send('Runtime.evaluate', {
  expression: `JSON.stringify({ href: location.href, ready: document.readyState, text: (document.body ? document.body.innerText : '').slice(0, 3000) })`,
  returnByValue: true
});
console.log('extensions page:', res.result.value.slice(0, 3000));
ws.close();
chrome.kill();
