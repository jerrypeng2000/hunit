import { convertDimensions, convertWeight } from '../src/shared/convert.js';
import { parseDimensionText, parseWeightText, parseCurrencyText } from '../src/shared/parser.js';

let failed = 0;

function check(name, actual, expected, tol = 0.01) {
  const ok = Math.abs(Number(actual) - Number(expected)) <= tol;
  if (!ok) failed += 1;
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}: ${actual} (expected ${expected})`);
}

function checkText(name, actual, expected) {
  const ok = String(actual) === String(expected);
  if (!ok) failed += 1;
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}: ${actual} (expected ${expected})`);
}

const r1 = convertDimensions({ mode: '1d', unit: 'cm', length: 100, precision: 2 });
check('1D 100cm -> in', r1.rows.find((x) => x.label === 'in').main, 39.37);

const r2 = convertDimensions({ mode: '2d', unit: 'in', length: 12, width: 8, precision: 2 });
const area = r2.rows.find((x) => x.label === '面积');
check('2D 12x8in area in2', area.main, 96);
check('2D 12x8in area cm2', area.alt, 619.35);
checkText('2D listing', r2.listing, '12.00 x 8.00 inches');

const r3 = convertDimensions({ mode: '3d', unit: 'in', length: 12, width: 6, height: 1, divisor: 139, precision: 2 });
const vol = r3.rows.find((x) => x.label === '体积');
const vw = r3.rows.find((x) => x.label === '体积重');
check('3D 12x6x1in vol in3', vol.main, 72);
check('3D 12x6x1in vol cm3', vol.alt, 1179.87);
check('3D vw 139 lb', vw.main, 0.52);

const r3b = convertDimensions({ mode: '3d', unit: 'cm', length: 30.48, width: 15.24, height: 2.54, divisor: 5000, precision: 2 });
const vwb = r3b.rows.find((x) => x.label === '体积重');
check('3D vw 5000 kg', vwb.main, 0.24);

const w = convertWeight(1, 'lb', 2);
check('1lb -> g', w.rows.find((x) => x.label === 'g').value, 453.59);
check('1lb -> kg', w.rows.find((x) => x.label === 'kg').value, 0.45);
check('1lb -> oz', w.rows.find((x) => x.label === 'oz').value, 16);

checkText('parse 12x6x1', JSON.stringify(parseDimensionText('12x6x1')), JSON.stringify({ mode: '3d', length: 12, width: 6, height: 1, unit: 'cm' }));
checkText('parse 30*15*2cm', JSON.stringify(parseDimensionText('30*15*2cm')), JSON.stringify({ mode: '3d', length: 30, width: 15, height: 2, unit: 'cm' }));
checkText('parse 3.3ft', JSON.stringify(parseDimensionText('3.3ft')), JSON.stringify({ mode: '1d', length: 3.3, unit: 'ft' }));
checkText('parse 12"', JSON.stringify(parseDimensionText('12"')), JSON.stringify({ mode: '1d', length: 12, unit: 'in' }));
checkText('parse 500g', JSON.stringify(parseWeightText('500g')), JSON.stringify({ value: 500, unit: 'g' }));
checkText('parse 2kg', JSON.stringify(parseWeightText('2kg')), JSON.stringify({ value: 2, unit: 'kg' }));
checkText('parse $20', JSON.stringify(parseCurrencyText('$20')), JSON.stringify({ amount: 20, currency: 'USD' }));

if (failed > 0) {
  console.error(`${failed} check(s) failed`);
  process.exit(1);
}
console.log('All checks passed');
