// Real UI test via raw Chrome DevTools Protocol (no puppeteer).
// - Downloads the extension release zip, extracts it
// - Launches Chrome with CDP and loads the unpacked extension
// - Drives the popup/app pages over CDP WebSocket and asserts behavior
import { spawn, execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync, existsSync, rmSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import http from 'node:http';
import net from 'node:net';
import { tmpdir } from 'node:os';

const root = resolve(import.meta.dirname, '..');
const screenshotDir = resolve(root, 'screenshots');
mkdirSync(screenshotDir, { recursive: true });

const CHROME = resolve(root, '..', '.tools', 'chrome-for-testing', 'chrome', 'win64-152.0.7977.54', 'chrome-win64', 'chrome.exe');
let PORT = 0;
let CDP = '';

const errors = [];
let chrome = null;
let server = null;
let browserCdp = null;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function getJson(url, timeout = 5000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const resp = await fetch(url, { signal: ctrl.signal });
    return await resp.json();
  } finally {
    clearTimeout(timer);
  }
}

async function createTarget(url) {
  const resp = await fetch(`${CDP}/json/new?${encodeURIComponent(url)}`, { method: 'PUT' });
  return await resp.json();
}

async function attachTarget(targetId) {
  const { sessionId } = await browserCdp.send('Target.attachToTarget', { targetId, flatten: true });
  return {
    send: (method, params = {}) => browserCdp.send(method, params, sessionId),
    close: () => browserCdp.send('Target.detachFromTarget', { sessionId }).catch(() => {})
  };
}

async function openPage(url) {
  const { targetId } = await browserCdp.send('Target.createTarget', { url });
  const page = await attachTarget(targetId);
  await page.send('Page.enable').catch(() => {});
  return page;
}

function pickFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port;
      srv.close(() => resolve(port));
    });
  });
}

async function waitForTarget(predicate, timeoutMs = 20000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const list = await getJson(`${CDP}/json/list`);
      const hit = list.find(predicate);
      if (hit) return hit;
    } catch (_) {}
    await sleep(300);
  }
  throw new Error('target not found');
}

async function connectCdp(wsUrl) {
  const ws = new WebSocket(wsUrl);
  await new Promise((resolveOpen, rejectOpen) => {
    ws.onopen = resolveOpen;
    ws.onerror = () => rejectOpen(new Error('ws error'));
  });
  let seq = 0;
  const pending = new Map();
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(JSON.stringify(msg.error)));
      else resolve(msg.result);
      return;
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      errors.push(`exception: ${msg.params?.exceptionDetails?.exception?.description || msg.params?.exceptionDetails?.text}`);
    }
    if (msg.method === 'Runtime.consoleAPICalled' && msg.params?.type === 'error') {
      errors.push(`console.error: ${(msg.params.args || []).map((a) => a.value || a.description || '').join(' ')}`);
    }
  };
  return {
    send(method, params = {}, sessionId = null) {
      return new Promise((resolve, reject) => {
        const id = ++seq;
        pending.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
      });
    },
    close() {
      try { ws.close(); } catch (_) {}
    }
  };
}

async function evaluate(cdp, expression) {
  const res = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (res.exceptionDetails) {
    throw new Error(`eval error: ${res.exceptionDetails.text} ${res.exceptionDetails.exception?.description || ''}`);
  }
  return res.result?.value;
}

async function evalRaw(cdp, expression) {
  const res = await cdp.send('Runtime.evaluate', { expression, returnByValue: true });
  if (res.exceptionDetails) {
    throw new Error(`eval error: ${res.exceptionDetails.text} ${res.exceptionDetails.exception?.description || ''}`);
  }
  return res.result?.value;
}

async function waitFor(cdp, expression, timeoutMs = 20000, label = 'condition') {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await evaluate(cdp, expression)) return;
    await sleep(400);
  }
  throw new Error(`timeout waiting for: ${label}`);
}

async function screenshot(cdp, file) {
  const res = await cdp.send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(resolve(screenshotDir, file), Buffer.from(res.data, 'base64'));
  console.log('screenshot saved:', file);
}

async function ensurePageLoaded(cdp, expectedPrefix, url, timeoutMs = 20000) {
  const start = Date.now();
  let lastHref = '';
  let lastReady = '';
  while (Date.now() - start < timeoutMs) {
    const href = await evaluate(cdp, 'location.href').catch(() => '');
    lastHref = href || '';
    if (href && href.startsWith(expectedPrefix)) {
      const ready = await evaluate(cdp, 'document.readyState').catch(() => '');
      lastReady = ready || '';
      if (ready === 'complete') return href;
    } else if (!href || href.startsWith('chrome-error://') || href === 'about:blank') {
      await cdp.send('Page.navigate', { url }).catch(() => {});
    }
    await sleep(500);
  }
  throw new Error(`page not loaded: ${url} (href=${lastHref}, ready=${lastReady})`);
}

function assert(cond, msg) {
  if (!cond) throw new Error(`ASSERT FAILED: ${msg}`);
  console.log('PASS:', msg);
}

// ---------- local page for content-script test ----------
server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>CDP 测试页</title></head><body><p>包装箱尺寸：<span id="dim">12x6x1</span>，重量 <span id="w">500g</span></p></body></html>`);
});
const serverPort = await pickFreePort();
await new Promise((r) => server.listen(serverPort, '127.0.0.1', r));

// ---------- launch Chrome with CDP and load the downloaded extension ----------
let profileDir = resolve(tmpdir(), `hunit-cdp-profile-${Date.now()}`);
const extDir = resolve(tmpdir(), 'hunit-cdp-test', 'extension');
rmSync(extDir, { recursive: true, force: true });
mkdirSync(extDir, { recursive: true });
const zipArg = process.argv[2] || null;
if (zipArg) {
  if (!existsSync(zipArg)) throw new Error('zip not found: ' + zipArg);
  execFileSync('tar', ['-xf', zipArg, '-C', extDir]);
  console.log('using local release zip:', zipArg);
} else {
  const zipTmp = resolve(tmpdir(), `hunit-cdp-download-${Date.now()}.zip`);
  execFileSync('curl', ['-s', '-L', '-o', zipTmp, 'https://gitee.com/pjtech/hunit/raw/master/release/hunit-v1.1.5-chromium.zip', '--max-time', '120']);
  execFileSync('tar', ['-xf', zipTmp, '-C', extDir]);
  rmSync(zipTmp, { force: true });
  console.log('downloaded release from Gitee');
}
const EXPECTED_VERSION = JSON.parse(readFileSync(resolve(extDir, 'manifest.json'), 'utf8')).version;
console.log('expected extension version:', EXPECTED_VERSION);

function launchChrome() {
  return spawn(CHROME, [
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profileDir}`,
    `--disable-extensions-except=${extDir}`,
    `--load-extension=${extDir}`,
    '--enable-unsafe-extension-debugging',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-gpu',
    '--window-position=-32000,-32000',
    'about:blank'
  ], { stdio: 'ignore' });
}

function cleanup() {
  try { if (chrome?.pid) spawn('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (_) {}
  try { if (chrome) chrome.kill(); } catch (_) {}
  try { if (server) server.close(); } catch (_) {}
  try { rmSync(profileDir, { recursive: true, force: true }); } catch (_) {}
}
process.on('exit', cleanup);
process.on('uncaughtException', (err) => { console.error(err); cleanup(); process.exit(1); });
process.on('unhandledRejection', (err) => { console.error(err); cleanup(); process.exit(1); });

async function waitVersion() {
  for (let i = 0; i < 60; i++) {
    try {
      await getJson(`${CDP}/json/version`, 3000);
      return;
    } catch (_) {
      if (chrome.exitCode !== null) throw new Error('chrome exited before CDP ready');
      await sleep(500);
    }
  }
  throw new Error('chrome CDP not ready');
}

// ---------- find OUR extension id from chrome://extensions-internals ----------
async function findOurExtensionIdFromInternals() {
  const c = await openPage('chrome://extensions-internals/');
  await c.send('Runtime.enable');
  const start = Date.now();
  let lastHref = '';
  let lastText = '';
  while (Date.now() - start < 25000) {
    const state = await evalRaw(c, `JSON.stringify({href: location.href, ready: document.readyState})`).catch(() => '{}');
    try { lastHref = JSON.parse(state).href || ''; } catch (_) {}
    if (lastHref.startsWith('chrome-error://')) {
      await c.send('Page.navigate', { url: 'chrome://extensions-internals/' }).catch(() => {});
    }
    const text = String(await evalRaw(c, `document.body.innerText || ''`).catch(() => '') || '');
    lastText = text;
    const idx = text.indexOf('换算通 HUnit');
    if (idx >= 0) {
      const before = text.slice(Math.max(0, idx - 1500), idx);
      const ids = [...before.matchAll(/"id":\s*"([a-p0-9]{32})"/g)].map((m) => m[1]);
      c.close();
      if (ids.length) return ids[ids.length - 1];
    }
    await sleep(500);
  }
  c.close();
  const ids = [...lastText.matchAll(/"id":\s*"([a-p0-9]{32})"/g)].length;
  return null;
}

async function waitForOurWorker() {
  const start = Date.now();
  while (Date.now() - start < 20000) {
    const list = await getJson(`${CDP}/json/list`);
    for (const t of list) {
      if (t.type !== 'service_worker') continue;
      try {
        const { sessionId } = await browserCdp.send('Target.attachToTarget', { targetId: t.id, flatten: true });
        const name = await Promise.race([
          browserCdp.send('Runtime.evaluate', {
            expression: `(async () => {
              try {
                const m = await (await fetch(chrome.runtime.getURL('manifest.json'))).json();
                return m.name || '';
              } catch (e) { return ''; }
            })()`,
            returnByValue: true,
            awaitPromise: true
          }, sessionId).then((r) => r.result?.value),
          new Promise((_, rej) => setTimeout(() => rej(new Error('worker timeout')), 5000))
        ]);
        if (name === '换算通 HUnit') {
          return new URL(t.url).host;
        }
      } catch (_) {}
    }
    await sleep(300);
  }
  return null;
}

let extensionId = null;
for (let attempt = 1; attempt <= 4 && !extensionId; attempt++) {
  PORT = await pickFreePort();
  CDP = `http://127.0.0.1:${PORT}`;
  profileDir = resolve(tmpdir(), `hunit-cdp-profile-${Date.now()}`);
  chrome = launchChrome();
  await waitVersion();
  browserCdp = await connectCdp((await getJson(`${CDP}/json/version`)).webSocketDebuggerUrl);
  console.log('Chrome CDP ready on port', PORT, `(attempt ${attempt})`);
  extensionId = await waitForOurWorker();
  if (!extensionId) {
    console.log('worker not found, falling back to extensions-internals ...');
    extensionId = await findOurExtensionIdFromInternals();
  }
  if (!extensionId) {
    const list = await getJson(`${CDP}/json/list`).catch(() => []);
    console.log(`extension not loaded on attempt ${attempt}; targets:`, list.map((t) => `${t.type} ${t.url}`).join(' | '));
    try { chrome.kill(); } catch (_) {}
    await sleep(1200);
  }
}
if (!extensionId) throw new Error('extension failed to load after 4 attempts');
console.log('extension id:', extensionId);

// ---------- open popup page ----------
const popup = await openPage(`chrome-extension://${extensionId}/popup.html`);
await popup.send('Runtime.enable');
await ensurePageLoaded(popup, 'chrome-extension://', `chrome-extension://${extensionId}/popup.html`);

// 1) installed copy is the downloaded v1.1.4
try {
  const t0 = Date.now();
  await waitFor(popup, `document.querySelector('#quotaValue') && document.querySelector('#quotaValue').textContent.trim() !== '—'`, 45000, 'quota load');
  const elapsed = Date.now() - t0;
  console.log(`quota visible in ${elapsed}ms`);
  if (elapsed > 15000) throw new Error('quota too slow: ' + elapsed + 'ms');
} catch (err) {
  const info = await evaluate(popup, `JSON.stringify({
    href: location.href,
    title: document.title,
    status: document.getElementById('statusText')?.textContent || null,
    quota: document.getElementById('quotaValue')?.textContent || null,
    membership: document.getElementById('membershipStatus')?.textContent || null
  })`).catch(() => 'eval failed');
  console.log('popup state on timeout:', info);
  throw err;
}
const manifestVersion = await evaluate(popup, `(async () => (await (await fetch(chrome.runtime.getURL('manifest.json'))).json()).version)()`);
assert(manifestVersion === EXPECTED_VERSION, `installed extension version = ${manifestVersion} (expected ${EXPECTED_VERSION})`);
const quota = await evaluate(popup, `document.querySelector('#quotaValue').textContent.trim()`);
assert(quota === '10', `local quota shows 10 (got ${quota})`);

// 2) membership panel
await evaluate(popup, `document.querySelector('#membershipBtn').click()`);
await waitFor(popup, `!document.querySelector('#upgradePanel').classList.contains('hidden')`, 5000, 'membership panel open');
const freeStatus = await evaluate(popup, `document.querySelector('#membershipStatus').textContent.trim()`);
assert(freeStatus.includes('免费版'), `membership free status: ${freeStatus}`);
const unsubHidden = await evaluate(popup, `document.querySelector('#unsubscribeButton').classList.contains('hidden')`);
assert(unsubHidden, 'unsubscribe hidden in free state');
await screenshot(popup, 'cdp-membership.png');

// 3) dimension conversion
await evaluate(popup, `document.querySelector('#membershipBtn').click()`);
await evaluate(popup, `
  document.querySelector('#modeSeg [data-mode="3d"]').click();
  document.querySelector('#dimUnit').value = 'in';
  document.querySelector('#dimLength').value = '12';
  document.querySelector('#dimWidth').value = '6';
  document.querySelector('#dimHeight').value = '1';
  ['dimLength','dimWidth','dimHeight'].forEach(id => document.getElementById(id).dispatchEvent(new Event('input')));
`);
await waitFor(popup, `document.querySelector('#dimLines .result-line')?.textContent.includes('30.48 cm')`, 8000, 'dimension result');
const dimText = await evaluate(popup, `Array.from(document.querySelectorAll('#dimLines .result-line')).map(el => el.textContent.trim()).join(' | ')`);
assert(dimText.includes('72.00 in³') && dimText.includes('0.24 kg'), '3D volume + volumetric weight computed');

// 4) pricing default rate + instant result
await evaluate(popup, `document.querySelector('.tab-btn[data-tab="price"]').click()`);
const rate = await evaluate(popup, `document.querySelector('#priceRate').value`);
assert(rate === '7.2', `pricing default rate = ${rate}`);
const liveRate = await (async () => {
  const start = Date.now();
  while (Date.now() - start < 15000) {
    await evaluate(popup, `document.querySelector('#useLiveRateBtn').click()`);
    const v = await evaluate(popup, `document.querySelector('#priceRate').value`);
    if (v && Number(v) > 0) return v;
    await sleep(500);
  }
  return null;
})();
assert(liveRate !== null, `live rate button fills rate (${liveRate})`);
await evaluate(popup, `
  const _pRate = document.getElementById('priceRate'); _pRate.value = '7.2'; _pRate.dispatchEvent(new Event('input'));
`);
await evaluate(popup, `
  const _pCost = document.getElementById('priceCost'); _pCost.value = '15'; _pCost.dispatchEvent(new Event('input'));
`);
await waitFor(popup, `document.querySelector('#priceResult')?.textContent.includes('$') && !document.querySelector('#priceResult').textContent.includes('$0.00')`, 8000, 'pricing result');
const price = await evaluate(popup, `document.querySelector('#priceResult').textContent.trim()`);
assert(price.includes('$3.19'), `pricing result ${price}`);
await screenshot(popup, 'cdp-pricing.png');

// 5) HS code search (real network)
await evaluate(popup, `document.querySelector('.tab-btn[data-tab="hs"]').click()`);
await evaluate(popup, `
  const _hsIn = document.getElementById('hsSearch'); _hsIn.value = '手机壳'; document.querySelector('#hsSearchBtn').click();
`);
await waitFor(popup, `document.querySelectorAll('#hsResults .hs-item').length > 0`, 30000, 'hs results');
const hsCount = await evaluate(popup, `document.querySelectorAll('#hsResults .hs-item').length`);
assert(hsCount > 0, `hs search returned ${hsCount} results`);
await screenshot(popup, 'cdp-hs.png');

// 6) settings: slug only, no appId field
await evaluate(popup, `document.querySelector('.tab-btn[data-tab="settings"]').click()`);
await sleep(300);
const slug = await evaluate(popup, `document.querySelector('#appSlug').value`);
const hasAppId = await evaluate(popup, `!!document.querySelector('#appId')`);
assert(slug === 'hunit' && !hasAppId, `settings slug=${slug}, appId field removed`);
await screenshot(popup, 'cdp-settings.png');

// 6b) common table type chips
await evaluate(popup, `document.querySelector('.tab-btn[data-tab="common"]').click()`);
await waitFor(popup, `document.querySelectorAll('#commonTypeChips .chip').length >= 7`, 5000, 'type chips rendered');
await evaluate(popup, `document.querySelector('#commonTypeChips .chip[data-type="dimension"]').click()`);
await sleep(200);
const chipActive = await evaluate(popup, `document.querySelector('#commonTypeChips .chip[data-type="dimension"]').classList.contains('active')`);
assert(chipActive, 'type chips filter works (dimension active)');
await evaluate(popup, `document.querySelector('#commonTypeChips .chip[data-type=""]').click()`);
await screenshot(popup, 'cdp-common-chips.png');

// 7) maximize window
await evaluate(popup, `document.querySelector('#maximizeFooterBtn').click()`);
const maxTarget = await waitForTarget((t) => t.type === 'page' && t.url.includes('app.html?window=1'), 15000);
const maxPage = await attachTarget(maxTarget.id);
await maxPage.send('Runtime.enable');
await waitFor(maxPage, `document.body.classList.contains('maximized')`, 10000, 'maximized class');
assert(true, 'maximized window opened with body.maximized');
await screenshot(maxPage, 'cdp-maximized.png');

// 8) content script selection tooltip on a normal web page
const page = await openPage(`http://127.0.0.1:${serverPort}/`);
await page.send('Runtime.enable');
await waitFor(page, `document.readyState === 'complete' && !!document.querySelector('#dim')`, 15000, 'local page loaded');
await evaluate(page, `
  const _selNode = document.getElementById('dim');
  const _selRange = document.createRange();
  _selRange.selectNodeContents(_selNode);
  const _sel = window.getSelection();
  _sel.removeAllRanges();
  _sel.addRange(_selRange);
  document.dispatchEvent(new Event('selectionchange'));
`);
await waitFor(page, `document.querySelector('#hunit-select-chip') && !document.querySelector('#hunit-select-chip').hidden`, 10000, 'select chip visible');
await evaluate(page, `document.querySelector('#hunit-select-chip').click()`);
await waitFor(page, `document.querySelector('#hunit-tooltip') && !document.querySelector('#hunit-tooltip').hidden && document.querySelector('#hunit-tooltip .hunit-tooltip-text').textContent.includes('长')`, 15000, 'tooltip result');
assert(true, 'content script tooltip shows conversion');
await screenshot(page, 'cdp-tooltip.png');

// ---------- summary ----------
popup.close();
if (maxPage) maxPage.close();
page.close();
if (errors.length) {
  console.error('Console errors detected:\n' + errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log('CDP real UI test passed');
}

try { rmSync(profileDir, { recursive: true, force: true }); } catch (_) {}
if (chrome) chrome.kill();
server.close();
