import puppeteer from 'puppeteer-core';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const screenshotDir = resolve(root, 'screenshots');
mkdirSync(screenshotDir, { recursive: true });

const TOKEN = process.env.HUNIT_TEST_TOKEN || 'XDyxhNnw9PjpqWzrJKsKHRemDwGLQz3AfBqOLIQTJPaEIrXC';

let browser;
const errors = [];
try {
  browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: false,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--window-position=-32000,-32000',
      `--disable-extensions-except=${dist}`,
      `--load-extension=${dist}`
    ],
    defaultViewport: { width: 1280, height: 900 }
  });

  await new Promise((r) => setTimeout(r, 2500));
  const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  console.log('extension id:', extensionId);

  const popup = await browser.newPage();
  popup.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`console: ${msg.text()}`);
  });
  popup.on('pageerror', (err) => errors.push(`pageerror: ${err.message}`));
  popup.on('dialog', (dialog) => dialog.accept());

  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => document.querySelector('#quotaValue')?.textContent.trim() !== '—', { timeout: 30000 });

  await popup.evaluate((token) => chrome.storage.sync.set({
    settings: {
      baseUrl: 'https://ajkapi.9zos.com',
      appSlug: 'hunit',
      appId: 0,
      accessToken: token,
      theme: 'auto',
      dimensionMode: '1d',
      scenario: 'listing',
      defaultUnit: 'cm',
      defaultCurrency: 'CNY',
      precision: 2,
      divisor: 5000,
      manualRatesEnabled: false,
      manualRates: { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 }
    }
  }), TOKEN);
  await popup.reload();
  try {
    await popup.waitForFunction(() => document.querySelector('#statusText')?.textContent.includes('已连接 AjkAPI'), { timeout: 40000 });
  } catch (err) {
    const st = await popup.$eval('#statusText', (el) => el.textContent).catch(() => 'n/a');
    const ms = await popup.$eval('#membershipStatus', (el) => el.textContent).catch(() => 'n/a');
    console.log('connection failed. status:', st, '| membership:', ms);
    throw err;
  }
  console.log('connected to AjkAPI');

  // 打开会员面板：免费状态
  await popup.click('#membershipBtn');
  await popup.waitForFunction(() => !document.querySelector('#upgradePanel')?.classList.contains('hidden'), { timeout: 5000 });
  const freeStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!freeStatus.includes('免费版')) throw new Error(`free status wrong: ${freeStatus}`);
  const subscribeVisible = await popup.$eval('#subscribeButton', (el) => !el.classList.contains('hidden'));
  const unsubscribeVisible = await popup.$eval('#unsubscribeButton', (el) => !el.classList.contains('hidden'));
  if (!subscribeVisible || unsubscribeVisible) throw new Error('subscribe/unsubscribe visibility wrong on free state');
  console.log('free state:', freeStatus);

  // 订购包月
  await popup.click('#subscribeButton');
  await popup.waitForFunction(() => document.querySelector('#membershipStatus')?.textContent.includes('会员已开通'), { timeout: 20000 });
  const proStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!proStatus.includes('有效期至')) throw new Error(`pro status wrong: ${proStatus}`);
  console.log('subscribed:', proStatus);
  await popup.screenshot({ path: resolve(screenshotDir, 'membership-subscribed.png') });

  // 退订包月（下月生效）
  await popup.click('#unsubscribeButton');
  await popup.waitForFunction(() => document.querySelector('#membershipStatus')?.textContent.includes('已退订'), { timeout: 20000 });
  const cancelledStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!cancelledStatus.includes('服务至')) throw new Error(`cancelled status wrong: ${cancelledStatus}`);
  const reSubscribeVisible = await popup.$eval('#subscribeButton', (el) => !el.classList.contains('hidden'));
  if (!reSubscribeVisible) throw new Error('re-subscribe button should be visible after cancel');
  console.log('cancelled:', cancelledStatus);
  await popup.screenshot({ path: resolve(screenshotDir, 'membership-cancelled.png') });

  if (errors.length) {
    console.error('Console errors:\n' + errors.join('\n'));
    process.exitCode = 1;
  } else {
    console.log('Membership UI test passed');
  }
} finally {
  if (browser) await browser.close();
}
