# -*- coding: utf-8 -*-
"""Generate HUnit extension icons."""
import os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICON_DIR = os.path.join(ROOT, "icons")
os.makedirs(ICON_DIR, exist_ok=True)

font_candidates = [
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    r"C:\Windows\Fonts\arial.ttf",
]


def load_font(size):
    for path in font_candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def make_icon(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    radius = int(size * 0.22)
    top = (63, 118, 255)
    bottom = (124, 58, 237)
    for y in range(size):
        color = lerp(top, bottom, y / max(size - 1, 1))
        draw.line([(0, y), (size, y)], fill=color + (255,))
    mask = Image.new("L", (size, size), 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    img.putalpha(mask)

    # white glyph
    font = load_font(int(size * 0.58))
    text = "换"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    x = (size - tw) / 2 - bbox[0]
    y = (size - th) / 2 - bbox[1]
    draw.text((x, y), text, font=font, fill=(255, 255, 255, 255))

    # small accent dot
    dot_r = max(2, int(size * 0.075))
    draw.ellipse(
        [size - dot_r * 2 - int(size * 0.05), int(size * 0.05), size - int(size * 0.05), int(size * 0.05) + dot_r * 2],
        fill=(52, 211, 153, 255),
    )
    return img


for size in (16, 32, 48, 128):
    icon = make_icon(size)
    path = os.path.join(ICON_DIR, f"icon{size}.png")
    icon.save(path)
    print("saved", path)
