import puppeteer from 'puppeteer-core';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';

const browser = await puppeteer.launch({
  executablePath: chromePath,
  headless: false,
  ignoreDefaultArgs: ['--disable-extensions'],
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-gpu',
    '--window-position=-32000,-32000',
    `--disable-extensions-except=${dist}`,
    `--load-extension=${dist}`
  ]
});

await new Promise((r) => setTimeout(r, 4000));
console.log('targets:');
for (const t of browser.targets()) {
  console.log(`  ${t.type()} ${t.url()}`);
}

const page = await browser.newPage();
await page.goto('chrome://extensions/');
await new Promise((r) => setTimeout(r, 3000));
const text = await page.evaluate(() => {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let out = '';
  let node;
  while ((node = walker.nextNode())) {
    if (node.shadowRoot) {
      out += node.shadowRoot.textContent.replace(/\s+/g, ' ').slice(0, 3000) + '\n';
    }
  }
  return out;
});
console.log('extensions page:', text.slice(0, 4000));
await browser.close();
