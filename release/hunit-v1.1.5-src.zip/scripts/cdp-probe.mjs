import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { tmpdir } from 'node:os';
import net from 'node:net';

const root = resolve(import.meta.dirname, '..');
const CHROME = resolve(root, '..', '.tools', 'chrome-for-testing', 'chrome', 'win64-152.0.7977.54', 'chrome-win64', 'chrome.exe');
const extDir = resolve(tmpdir(), 'hunit-cdp-test', 'extension');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function pickFreePort() {
  return new Promise((resolvePort, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port;
      srv.close(() => resolvePort(port));
    });
  });
}

const PORT = await pickFreePort();
const CDP = `http://127.0.0.1:${PORT}`;
const profileDir = resolve(tmpdir(), `hunit-cdp-probe-${Date.now()}`);
const chrome = spawn(CHROME, [
  `--remote-debugging-port=${PORT}`,
  `--user-data-dir=${profileDir}`,
  `--disable-extensions-except=${extDir}`,
  `--load-extension=${extDir}`,
  '--enable-unsafe-extension-debugging',
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-gpu',
  '--window-position=-32000,-32000',
  'about:blank'
], { stdio: 'ignore' });

for (let i = 0; i < 60; i++) {
  try { await fetch(`${CDP}/json/version`); break; } catch (_) { await sleep(500); }
}
console.log('CDP ready on', PORT);

const version = await (await fetch(`${CDP}/json/version`)).json();
const ws = new WebSocket(version.webSocketDebuggerUrl);
await new Promise((r) => { ws.onopen = r; });
let seq = 0;
const pending = new Map();
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    pending.get(msg.id)(msg.result);
    pending.delete(msg.id);
  }
};
const send = (method, params = {}, sessionId = null) => new Promise((resolveCmd) => {
  const id = ++seq;
  pending.set(id, resolveCmd);
  ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
});

// find our worker
let extId = null;
for (let i = 0; i < 40 && !extId; i++) {
  const list = await (await fetch(`${CDP}/json/list`)).json();
  for (const t of list) {
    if (t.type !== 'service_worker') continue;
    const { sessionId } = await send('Target.attachToTarget', { targetId: t.id, flatten: true });
    const res = await send('Runtime.evaluate', {
      expression: `(async () => { try { const m = await (await fetch(chrome.runtime.getURL('manifest.json'))).json(); return m.name || ''; } catch(e) { return ''; } })()`,
      returnByValue: true,
      awaitPromise: true
    }, sessionId);
    if (res.result?.value === '换算通 HUnit') { extId = new URL(t.url).host; break; }
  }
  await sleep(300);
}
console.log('extension id:', extId);

const { targetId } = await send('Target.createTarget', { url: `chrome-extension://${extId}/popup.html` });
console.log('created target:', targetId);
await sleep(3000);
const list = await (await fetch(`${CDP}/json/list`)).json();
const found = list.find((t) => t.id === targetId);
console.log('target url in list:', found ? found.url : 'NOT FOUND');
const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
const state = await send('Runtime.evaluate', { expression: `JSON.stringify({href: location.href, ready: document.readyState})`, returnByValue: true }, sessionId);
console.log('state:', JSON.stringify(state));
await sleep(5000);
const state2 = await send('Runtime.evaluate', { expression: `JSON.stringify({href: location.href, ready: document.readyState, title: document.title})`, returnByValue: true }, sessionId);
console.log('state2:', JSON.stringify(state2));

ws.close();
chrome.kill();
