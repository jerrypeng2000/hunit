import puppeteer from 'puppeteer-core';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const chromePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';

const browser = await puppeteer.launch({
  executablePath: chromePath,
  headless: false,
  ignoreDefaultArgs: ['--disable-extensions'],
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-gpu',
    '--window-position=-32000,-32000',
    `--disable-extensions-except=${dist}`,
    `--load-extension=${dist}`
  ]
});

await new Promise((r) => setTimeout(r, 2500));
const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
const extensionId = new URL(worker.url()).host;
const page = await browser.newPage();
page.on('console', (msg) => {
  if (msg.type() === 'error' || msg.type() === 'warning') console.log(`[${msg.type()}]`, msg.text());
});
page.on('pageerror', (err) => console.log('[pageerror]', err.message));
await page.goto(`chrome-extension://${extensionId}/popup.html`);
await new Promise((r) => setTimeout(r, 16000));
const probe = await page.evaluate(async () => {
  const loaded = !!window.__HUNIT_APP_LOADED__;
  const init = !!window.__HUNIT_APP_INIT__;
  let evalResult = null;
  try {
    const resp = await fetch(chrome.runtime.getURL('app.js'));
    const text = await resp.text();
    (0, eval)(text);
    evalResult = { ok: true, loadedAfter: !!window.__HUNIT_APP_LOADED__, initAfter: !!window.__HUNIT_APP_INIT__ };
  } catch (err) {
    evalResult = { ok: false, error: err.message, stack: (err.stack || '').slice(0, 500) };
  }
  return { loaded, init, evalResult };
});
console.log('probe:', JSON.stringify(probe, null, 1));
console.log('status:', await page.$eval('#statusText', (el) => el.textContent.trim()).catch(() => 'n/a'));
console.log('quota:', await page.$eval('#quotaValue', (el) => el.textContent.trim()).catch(() => 'n/a'));
console.log('membership:', await page.$eval('#membershipStatus', (el) => el.textContent.trim()).catch(() => 'n/a'));
await browser.close();
