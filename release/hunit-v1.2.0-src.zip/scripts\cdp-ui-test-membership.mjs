// 会员专项真实 UI 测试（Chrome for Testing + CDP，独立端口不与其它程序冲突）
// 用法：node scripts/cdp-ui-test-membership.mjs [zip 或 dist]
import puppeteer from 'puppeteer-core';
import { mkdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const screenshotDir = resolve(root, 'screenshots');
mkdirSync(screenshotDir, { recursive: true });

const CHROME = resolve(root, '..', '.tools', 'chrome-for-testing', 'chrome', 'win64-152.0.7977.54', 'chrome-win64', 'chrome.exe');
const TOKEN = process.env.HUNIT_TEST_TOKEN || 'XDyxhNnw9PjpqWzrJKsKHRemDwGLQz3AfBqOLIQTJPaEIrXC';
const dist = resolve(root, 'dist');

let browser;
const errors = [];
try {
  browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: false,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--window-position=-32000,-32000',
      `--disable-extensions-except=${dist}`,
      `--load-extension=${dist}`,
      '--enable-unsafe-extension-debugging'
    ],
    defaultViewport: { width: 1280, height: 900 }
  });

  await new Promise((r) => setTimeout(r, 2500));
  const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  console.log('extension id:', extensionId);

  const popup = await browser.newPage();
  popup.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(`console: ${msg.text()}`);
  });
  popup.on('pageerror', (err) => errors.push(`pageerror: ${err.message}`));
  popup.on('dialog', (dialog) => dialog.accept());

  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => document.querySelector('#quotaValue')?.textContent.trim() !== '—', { timeout: 30000 });

  // 写入 AjkAPI 连接（真实服务器）
  await popup.evaluate((token) => chrome.storage.sync.set({
    settings: {
      baseUrl: 'https://ajkapi.9zos.com',
      appSlug: 'hunit',
      appId: 0,
      accessToken: token,
      theme: 'auto',
      dimensionMode: '1d',
      scenario: 'listing',
      defaultUnit: 'cm',
      defaultCurrency: 'CNY',
      precision: 2,
      divisor: 5000,
      manualRatesEnabled: false,
      manualRates: { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 }
    }
  }), TOKEN);
  await popup.reload();
  try {
    await popup.waitForFunction(() => document.querySelector('#statusText')?.textContent.includes('已连接 AjkAPI'), { timeout: 40000 });
  } catch (err) {
    const st = await popup.$eval('#statusText', (el) => el.textContent).catch(() => 'n/a');
    const ms = await popup.$eval('#membershipStatus', (el) => el.textContent).catch(() => 'n/a');
    console.log('connection failed. status:', st, '| membership:', ms);
    throw err;
  }
  console.log('connected to AjkAPI');

  // 免费状态：显示服务端免费额度 + 充值按钮隐藏 + 订阅按钮含服务端价格
  await popup.click('#membershipBtn');
  await popup.waitForFunction(() => !document.querySelector('#upgradePanel')?.classList.contains('hidden'), { timeout: 5000 });
  const freeStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!freeStatus.includes('免费版')) throw new Error(`free status wrong: ${freeStatus}`);
  const subLabel = await popup.$eval('#subscribeButton', (el) => el.textContent.trim());
  if (!subLabel.includes('2 元/月')) throw new Error(`subscribe label missing server price: ${subLabel}`);
  const rechargeHidden = await popup.$eval('#rechargeButton', (el) => el.classList.contains('hidden'));
  if (!rechargeHidden) throw new Error('recharge button should be hidden in free state');
  console.log('free state:', freeStatus, '| button:', subLabel);

  // 订购包月：扣一次费，显示有效期 + 自动续费
  await popup.click('#subscribeButton');
  await popup.waitForFunction(() => document.querySelector('#membershipStatus')?.textContent.includes('会员已开通'), { timeout: 20000 });
  const proStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!proStatus.includes('有效期至')) throw new Error(`pro status wrong: ${proStatus}`);
  if (!proStatus.includes('自动续费')) throw new Error(`auto-renew text missing: ${proStatus}`);
  console.log('subscribed:', proStatus);
  await popup.screenshot({ path: resolve(screenshotDir, 'membership-subscribed-v2.png') });

  // 退订（到期后生效）
  await popup.click('#unsubscribeButton');
  await popup.waitForFunction(() => document.querySelector('#membershipStatus')?.textContent.includes('已退订'), { timeout: 20000 });
  const cancelledStatus = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!cancelledStatus.includes('服务至')) throw new Error(`cancelled status wrong: ${cancelledStatus}`);
  console.log('cancelled:', cancelledStatus);
  await popup.screenshot({ path: resolve(screenshotDir, 'membership-cancelled-v2.png') });

  if (errors.length) {
    console.error('Console errors:\n' + errors.join('\n'));
    process.exitCode = 1;
  } else {
    console.log('Membership v2 UI test passed');
  }
} finally {
  if (browser) await browser.close();
}
