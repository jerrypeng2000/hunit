// 续费失败 → 应用内充值提醒 真实 UI 测试
// 前置：python deploy/set_renew_failed_ui.py --setup（服务器上构造余额不足的过期订阅）
import puppeteer from 'puppeteer-core';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
const CHROME = resolve(root, '..', '.tools', 'chrome-for-testing', 'chrome', 'win64-152.0.7977.54', 'chrome-win64', 'chrome.exe');
const TOKEN = process.env.HUNIT_TEST_TOKEN || 'XDyxhNnw9PjpqWzrJKsKHRemDwGLQz3AfBqOLIQTJPaEIrXC';

let browser;
try {
  browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: false,
    ignoreDefaultArgs: ['--disable-extensions'],
    args: [
      '--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu',
      '--window-position=-32000,-32000',
      `--disable-extensions-except=${dist}`, `--load-extension=${dist}`,
      '--enable-unsafe-extension-debugging'
    ],
    defaultViewport: { width: 1280, height: 900 }
  });
  await new Promise((r) => setTimeout(r, 2500));
  const worker = await browser.waitForTarget((target) => target.type() === 'service_worker', { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  const popup = await browser.newPage();
  popup.on('dialog', (d) => d.accept());
  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.waitForFunction(() => document.querySelector('#quotaValue')?.textContent.trim() !== '—', { timeout: 30000 });
  await popup.evaluate((token) => chrome.storage.sync.set({
    settings: { baseUrl: 'https://ajkapi.9zos.com', appSlug: 'hunit', appId: 0, accessToken: token, theme: 'auto', dimensionMode: '1d', scenario: 'listing', defaultUnit: 'cm', defaultCurrency: 'CNY', precision: 2, divisor: 5000, manualRatesEnabled: false, manualRates: { USD: 1, CNY: 7.2, EUR: 0.92, GBP: 0.78, JPY: 148, AUD: 1.52, CAD: 1.37 } }
  }), TOKEN);
  await popup.reload();
  await popup.waitForFunction(() => document.querySelector('#statusText')?.textContent.includes('已连接 AjkAPI'), { timeout: 40000 });
  await popup.click('#membershipBtn');
  await popup.waitForFunction(() => !document.querySelector('#upgradePanel')?.classList.contains('hidden'), { timeout: 5000 });
  const status = await popup.$eval('#membershipStatus', (el) => el.textContent.trim());
  if (!status.includes('自动续费失败')) throw new Error(`renew-failed status wrong: ${status}`);
  const rechargeVisible = await popup.$eval('#rechargeButton', (el) => !el.classList.contains('hidden'));
  if (!rechargeVisible) throw new Error('recharge button should be visible after renew failure');
  const rechargeLabel = await popup.$eval('#rechargeButton', (el) => el.textContent.trim());
  console.log('renew-failed status:', status, '| recharge:', rechargeLabel);
  await popup.screenshot({ path: resolve(root, 'screenshots', 'membership-renewfail.png') });
  console.log('Renew-fail UI test passed');
} finally {
  if (browser) await browser.close();
}
